# Stitched-suite rebuttal experiments

Start with the [package README](../README.md) for the self-contained Colab and
local setup. The full input matrices are bundled in `../data/`.

| Experiment | Historical intervention |
|---|---|
| `00_clean_control` | None |
| `01_family_missingness` | Remove every Qwen2.5/QwQ M1 row |
| `02_temporal_missingness` | Retain only the oldest 50% of M1 |
| `03_random_label_corruption` | Flip exactly 5% of all M1 cells |
| `04_benchmark_label_corruption` | Put the same global 5% flip count inside BBH |
| `05_family_label_corruption` | Put the same global 5% flip count inside Qwen2.5/QwQ rows |
| `06_factor_prediction_accuracy` | Aggregate 00/01 by pre-query factor-accuracy quartile |

Every history-using method receives the same intervened matrix H'. The baseline
historical means are recomputed from that matrix. All methods are evaluated
against untouched clean M2 labels. Baseline variants are selected post hoc on
M2 by mean width, as in the original implementation.

The corruption conditions retain the same global burden:
`K = floor(0.05 * N_old * N_questions + 0.5)`.
On the full input, K is 1,058,406 flips. Concentrating them inside BBH gives
about 8.31% local corruption; concentrating them in Qwen2.5/QwQ gives about
84.39% local corruption. Report the local rate alongside the global 5% rate.

## Pipeline

```text
prepare_data → factor_models_cv → analyzing_factor_models
→ factor_models_val → faq_val → faq_val_analyzer
→ factor_models_final → factor_prediction_accuracy
→ faq_final → baselines_all → cleaning_results
```

Source-named files are thin wrappers; numerical code lives in `_shared/`.
See [SOURCE_MAPPING.md](SOURCE_MAPPING.md) and the individual condition READMEs.

## Validation

```bash
bash rebuttal_experiments/run_all_smoke_tests.sh --force
python -m rebuttal_experiments.verify_smoke_artifacts
```

Run from the package root. The first command already runs the verifier at the
end. Smoke outputs use `artifacts/smoke`; full outputs use `artifacts/full`.
See [the cleanup test report](../validation/SMOKE_TEST_REPORT.md).

Smoke checks are integration diagnostics, not scientific evidence. The full
clean control should approximately recover FAQ ESS multipliers 3.05x, 3.92x,
4.21x and the best-baseline multiplier near 2.27x at the three budgets before
interpreting stress conditions. Numerical differences across CPU/GPU and
library versions are possible.
