#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
"${PYTHON:-python3}" -m rebuttal_experiments._shared.cli \
  --experiment-dir "rebuttal_experiments/05_family_label_corruption" \
  --all --smoke \
  --device "${FAQ_DEVICE:-cpu}" "$@"
