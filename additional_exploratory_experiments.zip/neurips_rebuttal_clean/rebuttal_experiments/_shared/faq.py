"""Vectorized FAQ/PAI trial, preserving the public faq_final.py equations."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
from scipy.stats import norm

from .factor_model import resolve_device


@dataclass
class FAQTrialResult:
    estimate: np.ndarray
    standard_error: np.ndarray
    lower: np.ndarray
    upper: np.ndarray
    width: np.ndarray
    covered: np.ndarray
    true_accuracy: np.ndarray
    initial_factor_accuracy: np.ndarray
    final_factor_accuracy: np.ndarray
    n_queries: int

    @property
    def mean_width(self) -> float:
        return float(np.mean(self.width))

    @property
    def coverage(self) -> float:
        return float(np.mean(self.covered))


def budget_count(fraction: float, n_questions: int) -> int:
    # Public code: N_B = int(N_QUESTIONS * budget_prop).
    return max(1, int(int(n_questions) * float(fraction)))


def _binary_accuracy(probabilities: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    return ((probabilities >= 0.5) == (labels >= 0.5)).to(torch.float32).mean(dim=1)


def faq_trial(
    labels: np.ndarray,
    V: torch.Tensor,
    mu0: torch.Tensor,
    sigma0: torch.Tensor,
    *,
    budget_fraction: float,
    rho: float,
    gamma: float,
    beta0: float,
    tau: float,
    seed: int,
    alpha: float = 0.05,
    endpoint_mode: str = "source_exact",
    device: Optional[str] = None,
) -> FAQTrialResult:
    """Run one seed jointly over all models, exactly as the repository does.

    Rebuttal-only additions are per-model logging and initial/final binary factor
    prediction accuracy. They do not enter tuning or sampling.
    """
    dev = resolve_device(device)
    z = torch.as_tensor(labels, dtype=torch.float32, device=dev)
    if not torch.isfinite(z).all():
        raise ValueError("FAQ queried labels must be fully observed.")
    Vd = V.to(device=dev, dtype=torch.float32)
    mu = mu0.to(device=dev, dtype=torch.float32)
    cov = sigma0.to(device=dev, dtype=torch.float32)
    n_models, n_questions = z.shape
    n_budget = budget_count(budget_fraction, n_questions)

    Uhats = mu.unsqueeze(0).expand(n_models, -1).clone()
    Sigmahats = cov.unsqueeze(0).expand(n_models, -1, -1).clone()
    thetahats = torch.zeros((n_models, 1), dtype=torch.float32, device=dev)
    varhats_main = torch.zeros((n_models, 1), dtype=torch.float32, device=dev)
    varhats_inner1 = torch.zeros((n_models, 1), dtype=torch.float32, device=dev)
    varhats_inner2 = torch.zeros((n_models, n_budget), dtype=torch.float32, device=dev)

    torch.manual_seed(int(seed))
    if dev.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))

    with torch.no_grad():
        initial_prob = torch.sigmoid(Uhats @ Vd.T).clamp(1e-12, 1.0 - 1e-12)
        initial_accuracy = _binary_accuracy(initial_prob, z)

        for s in range(n_budget):
            # PART 1: source FAQ hybrid q_s(j).
            p_hat_js = torch.sigmoid(Uhats @ Vd.T).clamp(1e-12, 1.0 - 1e-12)
            p1mp = p_hat_js * (1.0 - p_hat_js)
            sqrt_p1mp = torch.sqrt(p1mp)
            ho_js = sqrt_p1mp / sqrt_p1mp.sum(dim=1, keepdim=True).clamp_min(1e-20)

            Sigmahats = (Sigmahats + Sigmahats.mT) / 2.0
            vtSigmav = torch.einsum("qi,mij,qj->mq", Vd, Sigmahats, Vd)
            log_denominator = torch.log1p(p1mp * vtSigmav)
            weighted_mean_v = (p1mp @ Vd) / float(n_questions)
            sigma_weighted_mean = torch.bmm(Sigmahats, weighted_mean_v.unsqueeze(-1)).squeeze(-1)
            sq_term = sigma_weighted_mean @ Vd.T
            log_numerator = torch.log(p1mp.clamp_min(1e-12)) + 2.0 * torch.log(
                sq_term.abs().clamp_min(1e-12)
            )
            ha_js = torch.softmax(log_numerator - log_denominator, dim=1)

            alpha_s = max(0.0, 1.0 - ((s + 1.0) / (float(rho) * n_budget))) if rho != 0.0 else 0.0
            beta_s = (
                float(beta0) * min((s + 1.0) / (float(gamma) * n_budget), 1.0)
                if gamma != 0.0
                else float(beta0)
            )
            hcat = (((1.0 - alpha_s) * ho_js) + (alpha_s * ha_js)).pow(beta_s)
            q_js = (hcat / hcat.sum(dim=1, keepdim=True).clamp_min(1e-20)) * (1.0 - float(tau))
            q_js = q_js + (float(tau) / n_questions)
            I_s = torch.multinomial(q_js, num_samples=1)

            # PART 2: PAI estimator and variance accumulators.
            z_Is = torch.gather(z, dim=1, index=I_s)
            phat_Is = torch.gather(p_hat_js, dim=1, index=I_s)
            q_Is = torch.gather(q_js, dim=1, index=I_s)
            prob_sums = p_hat_js.sum(dim=1, keepdim=True)
            aipw_s = (z_Is - phat_Is) / q_Is
            thetahats += prob_sums + aipw_s
            varhats_main += aipw_s.square()
            varhats_inner1 += z_Is / q_Is
            varhats_inner2[:, s] = prob_sums.flatten()

            # PART 3: source online Laplace update.
            w_s = torch.gather(p1mp, dim=1, index=I_s)
            v_Is = Vd[I_s.flatten()]
            Sigma_v = torch.bmm(Sigmahats, v_Is.unsqueeze(-1))
            vT_Sigma_v = torch.bmm(v_Is.unsqueeze(1), Sigma_v).squeeze(-1)
            denominator = 1.0 + (w_s * vT_Sigma_v)
            numerator = w_s.unsqueeze(-1) * (Sigma_v @ Sigma_v.mT)
            Sigmahats -= numerator / denominator.unsqueeze(-1)
            Uhats += torch.bmm(
                Sigmahats, ((z_Is - phat_Is) * v_Is).unsqueeze(-1)
            ).squeeze(-1)

        estimate = thetahats / (n_budget * n_questions)
        v_simp = varhats_main / (n_budget * (n_questions**2))
        v_minus = (((varhats_inner1 / n_budget) - varhats_inner2).square()).sum(
            dim=1, keepdim=True
        )
        v_minus /= n_budget * (n_questions**2)
        v_full = (v_simp - v_minus).clamp(min=0.0)
        standard_error = torch.sqrt(v_full / n_budget)
        z_score = float(norm.ppf(1.0 - (float(alpha) / 2.0)))
        raw_lower = estimate - z_score * standard_error
        raw_upper = estimate + z_score * standard_error
        if endpoint_mode == "source_exact":
            # Literal operations in public faq_final.py, retained for direct
            # comparability with the paper's logged widths/ESS.
            upper = torch.maximum(raw_upper, torch.tensor(0.0, device=dev))
            lower = torch.minimum(raw_lower, torch.tensor(1.0, device=dev))
        elif endpoint_mode == "corrected_clip":
            lower = torch.maximum(raw_lower, torch.tensor(0.0, device=dev))
            upper = torch.minimum(raw_upper, torch.tensor(1.0, device=dev))
        else:
            raise ValueError(f"Unknown endpoint_mode={endpoint_mode!r}")
        true_accuracy = z.mean(dim=1, keepdim=True)
        covered = (lower <= true_accuracy) & (true_accuracy <= upper)
        final_prob = torch.sigmoid(Uhats @ Vd.T).clamp(1e-12, 1.0 - 1e-12)
        final_accuracy = _binary_accuracy(final_prob, z)

    def arr(x: torch.Tensor) -> np.ndarray:
        return x.detach().cpu().numpy().reshape(-1)

    return FAQTrialResult(
        estimate=arr(estimate),
        standard_error=arr(standard_error),
        lower=arr(lower),
        upper=arr(upper),
        width=arr(upper - lower),
        covered=arr(covered).astype(bool),
        true_accuracy=arr(true_accuracy),
        initial_factor_accuracy=arr(initial_accuracy),
        final_factor_accuracy=arr(final_accuracy),
        n_queries=n_budget,
    )
