"""Command-line entry point shared by thin source-named experiment wrappers."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Callable, Sequence

from .pipeline import PIPELINE_ORDER, STAGE_FUNCTIONS, build_context


def run(
    *,
    experiment_dir: Path,
    stages: Sequence[str],
    smoke: bool,
    device: str | None,
    task_id: int,
    num_tasks: int,
    force: bool,
    endpoint_mode: str | None,
    after_stage: Callable[[str], None] | None = None,
) -> None:
    ctx = build_context(
        experiment_dir,
        smoke=smoke,
        device=device,
        endpoint_mode=endpoint_mode,
    )
    for stage in stages:
        print(f"\n=== {ctx.spec['experiment_id']}: {stage} ({'smoke' if smoke else 'full'}) ===")
        STAGE_FUNCTIONS[stage](
            ctx,
            task_id=task_id,
            num_tasks=num_tasks,
            force=force,
        )
        if after_stage is not None:
            after_stage(stage)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--experiment-dir", type=Path, required=True)
    stage_group = p.add_mutually_exclusive_group(required=True)
    stage_group.add_argument("--stage", choices=sorted(STAGE_FUNCTIONS))
    stage_group.add_argument("--all", action="store_true")
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--device", default=os.environ.get("FAQ_DEVICE"))
    p.add_argument("--task-id", type=int, default=0)
    p.add_argument("--num-tasks", type=int, default=1)
    p.add_argument("--force", action="store_true")
    p.add_argument(
        "--endpoint-mode",
        choices=["source_exact", "corrected_clip"],
        default=None,
        help="Main rebuttal results should retain source_exact for paper comparability.",
    )
    return p


def main(argv: Sequence[str] | None = None) -> None:
    args = parser().parse_args(argv)
    stages = PIPELINE_ORDER if args.all else [args.stage]
    run(
        experiment_dir=args.experiment_dir,
        stages=stages,
        smoke=bool(args.smoke),
        device=args.device,
        task_id=int(args.task_id),
        num_tasks=int(args.num_tasks),
        force=bool(args.force),
        endpoint_mode=args.endpoint_mode,
    )


def main_for_stage(experiment_dir: Path, stage: str) -> None:
    """Make a wrapper retain an original repository filename and CLI style."""

    p = argparse.ArgumentParser()
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--device", default=os.environ.get("FAQ_DEVICE"))
    p.add_argument("--task-id", type=int, default=0)
    p.add_argument("--num-tasks", type=int, default=1)
    p.add_argument("--force", action="store_true")
    p.add_argument(
        "--endpoint-mode", choices=["source_exact", "corrected_clip"], default=None
    )
    args = p.parse_args()
    run(
        experiment_dir=experiment_dir,
        stages=[stage],
        smoke=bool(args.smoke),
        device=args.device,
        task_id=int(args.task_id),
        num_tasks=int(args.num_tasks),
        force=bool(args.force),
        endpoint_mode=args.endpoint_mode,
    )


if __name__ == "__main__":
    main()
