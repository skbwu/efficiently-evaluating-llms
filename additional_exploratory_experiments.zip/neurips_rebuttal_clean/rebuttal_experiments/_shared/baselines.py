"""Source-faithful sequential AIPW baselines from baselines_all.py."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import torch
from scipy.stats import norm

from .factor_model import resolve_device
from .faq import budget_count


@dataclass
class BaselineResult:
    predictor: str
    estimate: np.ndarray
    standard_error: np.ndarray
    lower: np.ndarray
    upper: np.ndarray
    width: np.ndarray
    covered: np.ndarray
    true_accuracy: np.ndarray
    n_labels: np.ndarray

    @property
    def mean_width(self) -> float:
        return float(np.mean(self.width))

    @property
    def coverage(self) -> float:
        return float(np.mean(self.covered))


def historical_question_means(history: np.ndarray) -> np.ndarray:
    with np.errstate(invalid="ignore"):
        means = np.nanmean(history, axis=0)
        global_mean = float(np.nanmean(history))
    means = np.where(np.isfinite(means), means, global_mean)
    return means.astype(np.float32)


def baseline_trial(
    labels: np.ndarray,
    phats: np.ndarray,
    *,
    budget_fraction: float,
    policy: str,
    tau: float,
    seed: int,
    alpha: float = 0.05,
    device: Optional[str] = None,
) -> Dict[str, BaselineResult]:
    """One source trial; zero and historical predictors share Bernoulli draws."""
    dev = resolve_device(device)
    z = torch.as_tensor(labels, dtype=torch.float32, device=dev)
    p = torch.as_tensor(phats, dtype=torch.float32, device=dev)
    if not torch.isfinite(z).all() or not torch.isfinite(p).all():
        raise ValueError("Baseline labels and historical means must be finite.")
    n_models, n_questions = z.shape
    n_budget = budget_count(budget_fraction, n_questions)
    theta_zero = torch.zeros((n_models, 1), dtype=torch.float32, device=dev)
    var_zero = torch.zeros_like(theta_zero)
    theta_hist = torch.zeros_like(theta_zero)
    var_hist = torch.zeros_like(theta_zero)
    obs_counts = torch.zeros_like(theta_zero)
    ones = torch.ones_like(theta_zero)

    if policy == "sqrt":
        scores = torch.sqrt(p * (1.0 - p))
    elif policy in {"2min", "unif"}:
        scores = 2.0 * torch.minimum(1.0 - p, p)
    else:
        raise ValueError(f"Unsupported baseline policy {policy!r}")
    eta = n_budget / (n_questions * scores.mean().clamp_min(1e-20))

    torch.manual_seed(int(seed))
    if dev.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))
    with torch.no_grad():
        for t in range(n_questions):
            if policy == "unif":
                pi = (n_budget / n_questions) * ones
            else:
                n_delta = ((t + 1) * n_budget / n_questions) - obs_counts
                pi_raw = torch.minimum(eta * scores[t], n_delta).clamp(0.0, 1.0)
                pi = ((1.0 - float(tau)) * pi_raw) + (
                    float(tau) * (n_budget / n_questions)
                )
            xi = torch.bernoulli(pi * ones)
            outcome = z[:, t : t + 1]
            f_hist = p[t]
            theta_zero += (xi / pi) * outcome
            var_zero += (xi * (1.0 - pi) / pi.square()) * outcome.square()
            theta_hist += ((xi / pi) * (outcome - f_hist)) + f_hist
            var_hist += (xi * (1.0 - pi) / pi.square()) * (outcome - f_hist).square()
            obs_counts += xi

        true_accuracy = z.mean(dim=1, keepdim=True)
        z_score = float(norm.ppf(1.0 - (float(alpha) / 2.0)))

        def finish(predictor: str, theta_sum: torch.Tensor, var_sum: torch.Tensor) -> BaselineResult:
            estimate = theta_sum / n_questions
            standard_error = torch.sqrt(var_sum) / n_questions
            lower = torch.maximum(
                estimate - z_score * standard_error, torch.tensor(0.0, device=dev)
            )
            upper = torch.minimum(
                estimate + z_score * standard_error, torch.tensor(1.0, device=dev)
            )
            covered = (lower <= true_accuracy) & (true_accuracy <= upper)

            def arr(x: torch.Tensor) -> np.ndarray:
                return x.detach().cpu().numpy().reshape(-1)

            return BaselineResult(
                predictor=predictor,
                estimate=arr(estimate),
                standard_error=arr(standard_error),
                lower=arr(lower),
                upper=arr(upper),
                width=arr(upper - lower),
                covered=arr(covered).astype(bool),
                true_accuracy=arr(true_accuracy),
                n_labels=arr(obs_counts),
            )

        return {
            "zero": finish("zero", theta_zero, var_zero),
            "historical_mean": finish("historical_mean", theta_hist, var_hist),
        }
