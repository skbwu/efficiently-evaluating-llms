"""Data loading and deterministic row/question subsetting for rebuttal runs.

The public repository stores model metadata in the first three columns of M1
and M2 and uses every remaining column as one binary benchmark outcome.  This
module keeps that convention exactly.  M1/H may subsequently be modified only
inside :mod:`perturbations`; M2 is always retained as the clean fixed test bank.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

from .constants import METADATA_COLUMNS, STITCHED_SUITE


@dataclass(frozen=True)
class BaseData:
    """Unmodified M1/M2 matrices and their source-index mappings."""

    m1_path: Path
    m2_path: Path
    m1_meta: pd.DataFrame
    m2_meta: pd.DataFrame
    m1_values: np.ndarray
    m2_values: np.ndarray
    question_columns: list[str]
    original_m1_indices: np.ndarray
    original_m2_indices: np.ndarray
    original_question_indices: np.ndarray


@dataclass(frozen=True)
class ExperimentData:
    """Historical matrix after a declared intervention plus untouched M2."""

    history_meta: pd.DataFrame
    history_clean: np.ndarray
    history_perturbed: np.ndarray
    test_meta: pd.DataFrame
    test_values: np.ndarray
    question_columns: list[str]
    target_family_history_mask: np.ndarray
    target_family_test_mask: np.ndarray
    target_family: dict[str, Any]
    manifest: dict[str, Any]


def _resolve_data_path(
    *,
    env_name: str,
    spec_value: str | None,
    repo_root: Path,
    default_name: str,
) -> Path:
    """Resolve an input override, bundled matrix, or legacy repository path."""

    candidates: list[Path] = []
    env_value = os.environ.get(env_name)
    if env_value:
        candidates.append(Path(env_value).expanduser())
    if spec_value:
        raw = Path(spec_value).expanduser()
        candidates.append(raw if raw.is_absolute() else repo_root / raw)
    candidates.extend(
        [
            repo_root / "data" / default_name,
            repo_root / "data" / "processed" / STITCHED_SUITE / default_name,
            repo_root / "data" / "processed" / STITCHED_SUITE / default_name.lower(),
            repo_root / default_name,
        ]
    )
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate.is_file():
            return candidate
    formatted = "\n  - ".join(str(path) for path in candidates)
    raise FileNotFoundError(
        f"Could not find {default_name}. Set {env_name} explicitly. Tried:\n  - {formatted}"
    )


def _read_matrix(path: Path) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    """Read one matrix with float32 outcomes and untouched metadata strings."""

    header = pd.read_csv(path, nrows=0)
    columns = list(header.columns)
    metadata = list(METADATA_COLUMNS)
    if columns[: len(metadata)] != metadata:
        raise ValueError(
            f"{path} must begin with metadata columns {metadata}; found {columns[:len(metadata)]}."
        )
    question_columns = columns[len(metadata) :]
    if not question_columns:
        raise ValueError(f"{path} contains no benchmark-question columns.")

    # The explicit dtype map keeps the 21M-cell matrices near float32 memory
    # usage. Metadata is loaded as object/string exactly as in the public code.
    dtype = {column: np.float32 for column in question_columns}
    frame = pd.read_csv(path, dtype=dtype, low_memory=False)
    meta = frame.loc[:, metadata].copy()
    values = frame.loc[:, question_columns].to_numpy(dtype=np.float32, copy=True)
    return meta, values, question_columns


def load_base_data(repo_root: Path, spec: Mapping[str, Any]) -> BaseData:
    """Load supplied M1/M2 while enforcing a common stitched question bank."""

    data_spec = spec.get("data", {}) if isinstance(spec.get("data", {}), Mapping) else {}
    m1_path = _resolve_data_path(
        env_name="FAQ_M1_PATH",
        spec_value=data_spec.get("m1_path"),
        repo_root=repo_root,
        default_name="M1.csv",
    )
    m2_path = _resolve_data_path(
        env_name="FAQ_M2_PATH",
        spec_value=data_spec.get("m2_path"),
        repo_root=repo_root,
        default_name="M2.csv",
    )
    m1_meta, m1_values, m1_questions = _read_matrix(m1_path)
    m2_meta, m2_values, m2_questions = _read_matrix(m2_path)
    if m1_questions != m2_questions:
        first_mismatch = next(
            (
                idx
                for idx, (left, right) in enumerate(zip(m1_questions, m2_questions))
                if left != right
            ),
            None,
        )
        raise ValueError(
            "M1 and M2 question columns differ"
            + (f" first at index {first_mismatch}." if first_mismatch is not None else ".")
        )
    if not np.isfinite(m2_values).all():
        raise ValueError("M2 must be fully observed because it supplies clean fixed test outcomes.")

    return BaseData(
        m1_path=m1_path,
        m2_path=m2_path,
        m1_meta=m1_meta.reset_index(drop=True),
        m2_meta=m2_meta.reset_index(drop=True),
        m1_values=m1_values,
        m2_values=m2_values,
        question_columns=list(m1_questions),
        original_m1_indices=np.arange(len(m1_meta), dtype=np.int64),
        original_m2_indices=np.arange(len(m2_meta), dtype=np.int64),
        original_question_indices=np.arange(len(m1_questions), dtype=np.int64),
    )


def benchmark_counts(question_columns: Sequence[str]) -> dict[str, int]:
    """Count stitched-suite columns by the prefix before the first underscore."""

    counts: dict[str, int] = {}
    for column in question_columns:
        key = str(column).split("_", 1)[0].lower()
        counts[key] = counts.get(key, 0) + 1
    return counts


def _balanced_question_subset(question_columns: Sequence[str], limit: int) -> np.ndarray:
    """Deterministic smoke subset containing every stitched constituent."""

    n_questions = len(question_columns)
    if limit >= n_questions:
        return np.arange(n_questions, dtype=np.int64)
    groups: dict[str, list[int]] = {}
    order: list[str] = []
    for idx, column in enumerate(question_columns):
        key = str(column).split("_", 1)[0].lower()
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(idx)

    selected: list[int] = []
    pointers = {key: 0 for key in order}
    while len(selected) < limit:
        made_progress = False
        for key in order:
            pointer = pointers[key]
            if pointer < len(groups[key]) and len(selected) < limit:
                selected.append(groups[key][pointer])
                pointers[key] = pointer + 1
                made_progress = True
        if not made_progress:
            break
    return np.array(sorted(selected), dtype=np.int64)


def _row_subset_with_family(
    meta: pd.DataFrame,
    *,
    pattern: str,
    limit: int,
    minimum_family_rows: int,
) -> np.ndarray:
    """Smoke-only deterministic rows with enough family and non-family cases."""

    if limit >= len(meta):
        return np.arange(len(meta), dtype=np.int64)
    mask = meta["model"].astype(str).str.contains(pattern, regex=True, na=False).to_numpy()
    family = np.flatnonzero(mask)
    other = np.flatnonzero(~mask)
    n_family = min(len(family), minimum_family_rows, limit)
    n_other = min(len(other), limit - n_family)
    selected = np.concatenate([family[:n_family], other[:n_other]])
    if len(selected) < limit:
        already = np.zeros(len(meta), dtype=bool)
        already[selected] = True
        selected = np.concatenate([selected, np.flatnonzero(~already)[: limit - len(selected)]])
    return np.sort(selected.astype(np.int64, copy=False))


def apply_smoke_subset(
    base: BaseData,
    *,
    target_pattern: str,
    limits: Mapping[str, Any],
) -> BaseData:
    """Create a small deterministic integration-test view of M1/M2."""

    history_idx = _row_subset_with_family(
        base.m1_meta,
        pattern=target_pattern,
        limit=int(limits["history_rows"]),
        minimum_family_rows=int(limits["minimum_family_history_rows"]),
    )
    test_idx = _row_subset_with_family(
        base.m2_meta,
        pattern=target_pattern,
        limit=int(limits["test_rows"]),
        minimum_family_rows=int(limits["minimum_family_test_rows"]),
    )
    question_idx = _balanced_question_subset(
        base.question_columns, int(limits["questions"])
    )
    return BaseData(
        m1_path=base.m1_path,
        m2_path=base.m2_path,
        m1_meta=base.m1_meta.iloc[history_idx].reset_index(drop=True),
        m2_meta=base.m2_meta.iloc[test_idx].reset_index(drop=True),
        m1_values=base.m1_values[np.ix_(history_idx, question_idx)].copy(),
        m2_values=base.m2_values[np.ix_(test_idx, question_idx)].copy(),
        question_columns=[base.question_columns[idx] for idx in question_idx],
        original_m1_indices=base.original_m1_indices[history_idx].copy(),
        original_m2_indices=base.original_m2_indices[test_idx].copy(),
        original_question_indices=base.original_question_indices[question_idx].copy(),
    )


def split_history_rows(n_rows: int, train_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    """Public chronological split: first floor(0.8N), then the remaining rows."""

    if n_rows < 2:
        raise ValueError("At least two available historical rows are required for train/validation.")
    n_train = int(n_rows * float(train_fraction))
    n_train = min(max(n_train, 1), n_rows - 1)
    return (
        np.arange(n_train, dtype=np.int64),
        np.arange(n_train, n_rows, dtype=np.int64),
    )
