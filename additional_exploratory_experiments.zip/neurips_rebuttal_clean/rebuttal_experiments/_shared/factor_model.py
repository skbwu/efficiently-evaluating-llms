"""Source-faithful logistic matrix factorization and 1-SE selection."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from sklearn.model_selection import KFold

from .io_utils import read_json, write_json


@dataclass
class FactorFit:
    U: torch.Tensor
    V: torch.Tensor
    final_loss: float


def resolve_device(device: Optional[str]) -> torch.device:
    if device:
        requested = torch.device(device)
        if requested.type == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("FAQ_DEVICE/cmd requested CUDA, but torch.cuda.is_available() is false.")
        return requested
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def fit_logistic_factor_model(
    values: np.ndarray,
    *,
    k: int,
    weight_decay: float,
    learning_rate: float,
    max_epochs: int,
    seed: int,
    train_mask: Optional[np.ndarray] = None,
    device: Optional[str] = None,
) -> FactorFit:
    """Mirror factor_models_final.py: randn U/V, AdamW, masked BCE logits."""
    dev = resolve_device(device)
    labels = torch.as_tensor(values, dtype=torch.float32, device=dev)
    observed = torch.isfinite(labels)
    if train_mask is not None:
        mask = torch.as_tensor(train_mask, dtype=torch.bool, device=dev) & observed
    else:
        mask = observed
    if int(mask.sum()) == 0:
        raise ValueError("Factor fit has no observed training entries.")
    torch.manual_seed(int(seed))
    if dev.type == "cuda":
        torch.cuda.manual_seed_all(int(seed))
    U = torch.nn.Parameter(torch.randn((labels.shape[0], int(k)), device=dev))
    V = torch.nn.Parameter(torch.randn((labels.shape[1], int(k)), device=dev))
    optimizer = torch.optim.AdamW(
        [{"params": [U, V], "weight_decay": float(weight_decay)}],
        lr=float(learning_rate),
    )
    final_loss = float("nan")
    for _ in range(int(max_epochs)):
        logits = U @ V.T
        loss = F.binary_cross_entropy_with_logits(logits[mask], labels[mask])
        loss.backward()
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        final_loss = float(loss.detach().cpu())
    return FactorFit(U=U.detach().cpu(), V=V.detach().cpu(), final_loss=final_loss)


def make_entry_folds(values: np.ndarray, n_folds: int, seed: int) -> np.ndarray:
    """Mirror public ``KFold(...).split(M1.flatten())`` exactly.

    The public script assigns folds over *all* flattened matrix locations and
    only afterward intersects the train/validation masks with the observed-entry
    mask.  Preserving that order matters for missing-history experiments.
    """
    folds = np.full(values.size, -1, dtype=np.int16)
    splitter = KFold(n_splits=int(n_folds), shuffle=True, random_state=int(seed))
    dummy = np.empty(values.size, dtype=np.uint8)
    for fold, (_, validation_indices) in enumerate(splitter.split(dummy)):
        folds[validation_indices] = int(fold)
    return folds.reshape(values.shape)


def binary_prediction_accuracy(
    fit: FactorFit,
    values: np.ndarray,
    eval_mask: np.ndarray,
    *,
    device: Optional[str] = None,
) -> float:
    dev = resolve_device(device)
    U = fit.U.to(dev)
    V = fit.V.to(dev)
    mask = torch.as_tensor(eval_mask, dtype=torch.bool, device=dev)
    labels = torch.as_tensor(values, dtype=torch.float32, device=dev)
    with torch.no_grad():
        predictions = (torch.sigmoid(U @ V.T) >= 0.5).to(torch.float32)
        return float((predictions[mask] == labels[mask]).to(torch.float32).mean().cpu())


def select_factor_setting_one_se(cv_rows: pd.DataFrame) -> Dict[str, Any]:
    """Mirror public ``analyzing_factor_models.py`` one-SE selection.

    The source uses NumPy's population standard deviation (``ddof=0``), divides
    it by ``sqrt(5)``, uses a strict ``>`` cutoff, then chooses the smallest
    rank and largest weight decay.
    """
    required = {"k", "weight_decay", "fold", "prediction_accuracy"}
    if not required.issubset(cv_rows.columns):
        raise ValueError(f"CV log missing columns {sorted(required.difference(cv_rows.columns))}")

    grouped = cv_rows.groupby(["k", "weight_decay"])["prediction_accuracy"]
    summary = grouped.agg(
        mean="mean",
        std_population=lambda values: float(np.std(values.to_numpy(), ddof=0)),
        count="count",
    ).reset_index()
    summary["se"] = summary["std_population"] / np.sqrt(summary["count"].clip(lower=1))
    best = summary.sort_values("mean", ascending=False, kind="stable").iloc[0]
    threshold = float(best["mean"] - best["se"])
    eligible = summary.loc[summary["mean"] > threshold].copy()
    if eligible.empty:
        # A zero standard error can exclude the best setting at the strict
        # cutoff. In that case retain a highest-accuracy setting.
        eligible = summary.loc[[summary["mean"].idxmax()]].copy()
    eligible = eligible.sort_values(
        ["k", "weight_decay"], ascending=[True, False], kind="stable"
    )
    selected = eligible.iloc[0]
    return {
        "k": int(selected["k"]),
        "weight_decay": float(selected["weight_decay"]),
        "selected_cv_mean_accuracy": float(selected["mean"]),
        "selected_cv_se": float(selected["se"]),
        "best_cv_mean_accuracy": float(best["mean"]),
        "best_cv_se": float(best["se"]),
        "one_se_threshold": threshold,
        "selection_rule": (
            "public source: mean accuracy strictly above best mean minus "
            "population-SD/sqrt(n_folds); then smallest k and largest weight decay"
        ),
    }


def save_factor_fit(fit: FactorFit, directory: Path, metadata: Dict[str, Any]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "metadata.json").unlink(missing_ok=True)
    torch.save(fit.U, directory / "U.pt")
    torch.save(fit.V, directory / "V.pt")
    write_json(directory / "metadata.json", {**metadata, "final_train_loss": fit.final_loss})


def load_factor_fit(directory: Path) -> FactorFit:
    metadata = read_json(directory / "metadata.json")
    return FactorFit(
        U=torch.load(directory / "U.pt", map_location="cpu", weights_only=True),
        V=torch.load(directory / "V.pt", map_location="cpu", weights_only=True),
        final_loss=float(metadata.get("final_train_loss", float("nan"))),
    )


def prior_from_historical_factors(U: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    U = U.to(torch.float32)
    mean = U.mean(dim=0)
    if U.shape[0] < 2:
        covariance = torch.eye(U.shape[1], dtype=torch.float32)
    else:
        covariance = torch.cov(U.T)
    # Public faq_val.py/faq_final.py use torch.cov(U.T) directly.  Do not add
    # a rebuttal-only ridge term: retaining the literal source prior keeps
    # validation choices and final ESS directly comparable to the paper.
    covariance = (covariance + covariance.T) / 2
    return mean, covariance
