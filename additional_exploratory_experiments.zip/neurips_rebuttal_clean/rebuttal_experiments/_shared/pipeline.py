"""Stage-by-stage orchestration preserving the repository's experiment workflow."""
from __future__ import annotations

import itertools
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch

from .baselines import baseline_trial, historical_question_means
from .constants import get_default_config
from .data import BaseData, ExperimentData, load_base_data, split_history_rows
from .factor_model import (
    FactorFit,
    binary_prediction_accuracy,
    fit_logistic_factor_model,
    load_factor_fit,
    make_entry_folds,
    prior_from_historical_factors,
    save_factor_fit,
    select_factor_setting_one_se,
)
from .faq import budget_count, faq_trial
from .io_utils import (
    concat_csvs,
    ensure_dirs,
    load_experiment_spec,
    read_json,
    repo_root_from_experiment,
    write_csv_atomic,
    write_json,
)
from .perturbations import prepare_experiment_data


@dataclass
class Context:
    experiment_dir: Path
    repo_root: Path
    spec: Dict[str, Any]
    config: Dict[str, Any]
    paths: Dict[str, Path]
    base: BaseData
    data: ExperimentData
    train_idx: np.ndarray
    val_idx: np.ndarray
    device: Optional[str]


def _deep_update(base: Dict[str, Any], updates: Mapping[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for key, value in updates.items():
        if isinstance(value, Mapping) and isinstance(out.get(key), Mapping):
            out[key] = _deep_update(dict(out[key]), value)
        else:
            out[key] = value
    return out


def build_context(
    experiment_dir: Path,
    *,
    smoke: bool,
    device: Optional[str] = None,
    endpoint_mode: Optional[str] = None,
) -> Context:
    experiment_dir = experiment_dir.resolve()
    repo_root = repo_root_from_experiment(experiment_dir)
    spec = load_experiment_spec(experiment_dir)
    config = get_default_config(smoke=smoke)
    config = _deep_update(config, spec.get("config_overrides", {}))
    if endpoint_mode is not None:
        config["faq_interval_endpoint_mode"] = endpoint_mode
    paths = ensure_dirs(experiment_dir, smoke=smoke)
    base = load_base_data(repo_root, spec)
    data = prepare_experiment_data(base, spec, config, paths["manifests"])
    train_idx, val_idx = split_history_rows(
        len(data.history_meta), float(config["train_fraction"])
    )
    resolved = {
        **config,
        "experiment_id": spec["experiment_id"],
        "perturbation": spec["perturbation"],
        "resolved_m1_path": str(base.m1_path),
        "resolved_m2_path": str(base.m2_path),
        "history_rows_available": int(len(data.history_meta)),
        "history_train_rows": int(len(train_idx)),
        "history_validation_rows": int(len(val_idx)),
        "test_rows": int(len(data.test_meta)),
        "questions": int(len(data.question_columns)),
        "budget_counts": {
            str(b): budget_count(float(b), len(data.question_columns))
            for b in config["budgets"]
        },
    }
    write_json(paths["root"] / "resolved_run_config.json", resolved)
    return Context(
        experiment_dir=experiment_dir,
        repo_root=repo_root,
        spec=spec,
        config=config,
        paths=paths,
        base=base,
        data=data,
        train_idx=train_idx,
        val_idx=val_idx,
        device=device,
    )


def _shard(items: Sequence[Any], task_id: int, num_tasks: int) -> List[Any]:
    if num_tasks < 1 or not 0 <= task_id < num_tasks:
        raise ValueError(f"Need 0 <= task_id < num_tasks; got {task_id}, {num_tasks}")
    return [item for idx, item in enumerate(items) if idx % num_tasks == task_id]


def _output_path(ctx: Context, stem: str, task_id: int, num_tasks: int) -> Path:
    suffix = f"_task{task_id:03d}-of-{num_tasks:03d}" if num_tasks > 1 else ""
    return ctx.paths["logs"] / f"{stem}{suffix}.csv"


def stage_prepare_data(ctx: Context, **_: Any) -> None:
    print(json.dumps(ctx.data.manifest, indent=2, default=str))


def stage_factor_cv(
    ctx: Context,
    *,
    task_id: int = 0,
    num_tasks: int = 1,
    force: bool = False,
    **_: Any,
) -> None:
    out = _output_path(ctx, "factor_model_cv", task_id, num_tasks)
    if out.exists() and not force:
        print(f"[skip] {out}")
        return
    train_values = ctx.data.history_perturbed[ctx.train_idx]
    fm = ctx.config["factor_model"]
    folds = make_entry_folds(train_values, int(fm["cv_folds"]), int(fm["seed"]))
    items = list(
        itertools.product(
            fm["dimensions"], fm["weight_decays"], range(int(fm["cv_folds"]))
        )
    )
    rows: List[Dict[str, Any]] = []
    for k, wd, fold in _shard(items, task_id, num_tasks):
        finite = np.isfinite(train_values)
        train_mask = (folds != int(fold)) & finite
        eval_mask = (folds == int(fold)) & finite
        fit = fit_logistic_factor_model(
            train_values,
            k=int(k),
            weight_decay=float(wd),
            learning_rate=float(fm["learning_rate"]),
            max_epochs=int(fm["max_epochs"]),
            seed=int(fm["seed"]),
            train_mask=train_mask,
            device=ctx.device,
        )
        accuracy = binary_prediction_accuracy(
            fit, train_values, eval_mask, device=ctx.device
        )
        row = {
            "experiment_id": ctx.spec["experiment_id"],
            "k": int(k),
            "weight_decay": float(wd),
            "fold": int(fold),
            "prediction_accuracy": accuracy,
            "final_train_loss": fit.final_loss,
            "n_train_entries": int(train_mask.sum()),
            "n_validation_entries": int(eval_mask.sum()),
        }
        rows.append(row)
        print(f"[factor-cv] {row}", flush=True)
    write_csv_atomic(pd.DataFrame(rows), out)


def stage_analyze_factor_models(ctx: Context, *, force: bool = False, **_: Any) -> None:
    out_json = ctx.paths["results"] / "selected_factor_setting.json"
    if out_json.exists() and (ctx.paths["results"] / "selected_factor_setting.csv").exists() and not force:
        print(f"[skip] {out_json}")
        return
    rows = concat_csvs(ctx.paths["logs"].glob("factor_model_cv*.csv"))
    if rows.empty:
        raise FileNotFoundError("No factor_model_cv*.csv logs. Run factor_models_cv.py first.")
    selected = select_factor_setting_one_se(rows)
    write_json(out_json, selected)
    write_csv_atomic(
        pd.DataFrame([selected]),
        ctx.paths["results"] / "selected_factor_setting.csv",
    )
    print(f"[factor-selection] {selected}")


def _selected_factor(ctx: Context) -> Dict[str, Any]:
    return read_json(ctx.paths["results"] / "selected_factor_setting.json")


def stage_factor_val(ctx: Context, *, force: bool = False, **_: Any) -> None:
    target = ctx.paths["factors"] / "validation"
    if all((target / name).is_file() for name in ("U.pt", "V.pt", "metadata.json")) and not force:
        print(f"[skip] {target}")
        return
    sel = _selected_factor(ctx)
    fm = ctx.config["factor_model"]
    fit = fit_logistic_factor_model(
        ctx.data.history_perturbed[ctx.train_idx],
        k=int(sel["k"]),
        weight_decay=float(sel["weight_decay"]),
        learning_rate=float(fm["learning_rate"]),
        max_epochs=int(fm["max_epochs"]),
        seed=int(fm["seed"]),
        device=ctx.device,
    )
    save_factor_fit(
        fit,
        target,
        {
            "source_stage": "factor_models_val.py",
            "training_rows": int(len(ctx.train_idx)),
            "k": int(sel["k"]),
            "weight_decay": float(sel["weight_decay"]),
        },
    )


def _faq_grid(ctx: Context) -> List[Tuple[float, float, float, float, float, int]]:
    faq = ctx.config["faq"]
    return list(
        itertools.product(
            ctx.config["budgets"],
            faq["rho"],
            faq["gamma"],
            faq["beta0"],
            faq["tau"],
            range(int(faq["validation_seeds"])),
        )
    )


def stage_faq_val(
    ctx: Context,
    *,
    task_id: int = 0,
    num_tasks: int = 1,
    force: bool = False,
    **_: Any,
) -> None:
    out = _output_path(ctx, "faq_validation", task_id, num_tasks)
    if out.exists() and not force:
        print(f"[skip] {out}")
        return
    fit = load_factor_fit(ctx.paths["factors"] / "validation")
    mu0, sigma0 = prior_from_historical_factors(fit.U)
    # Historical logs may be corrupted, but held-out validation outcomes are
    # freshly queried and therefore read from the clean copy.
    labels = ctx.data.history_clean[ctx.val_idx]
    rows: List[Dict[str, Any]] = []
    for budget, rho, gamma, beta0, tau, seed in _shard(
        _faq_grid(ctx), task_id, num_tasks
    ):
        result = faq_trial(
            labels,
            fit.V,
            mu0,
            sigma0,
            budget_fraction=float(budget),
            rho=float(rho),
            gamma=float(gamma),
            beta0=float(beta0),
            tau=float(tau),
            seed=int(seed),
            alpha=float(ctx.config["alpha"]),
            endpoint_mode=str(ctx.config["faq_interval_endpoint_mode"]),
            device=ctx.device,
        )
        row = {
            "experiment_id": ctx.spec["experiment_id"],
            "budget_fraction": float(budget),
            "n_queries": result.n_queries,
            "rho": float(rho),
            "gamma": float(gamma),
            "beta0": float(beta0),
            "tau": float(tau),
            "seed": int(seed),
            "mean_width": result.mean_width,
            "coverage": result.coverage,
        }
        rows.append(row)
        print(f"[faq-val] {row}", flush=True)
    write_csv_atomic(pd.DataFrame(rows), out)


def stage_faq_val_analyzer(ctx: Context, *, force: bool = False, **_: Any) -> None:
    out = ctx.paths["results"] / "selected_faq_settings.csv"
    if out.exists() and not force:
        print(f"[skip] {out}")
        return
    rows = concat_csvs(ctx.paths["logs"].glob("faq_validation*.csv"))
    if rows.empty:
        raise FileNotFoundError("No faq_validation*.csv logs. Run faq_val.py first.")
    keys = ["budget_fraction", "rho", "gamma", "beta0", "tau"]
    means = (
        rows.groupby(keys, as_index=False)
        .agg(mean_width=("mean_width", "mean"), coverage=("coverage", "mean"))
        .sort_values(keys, kind="stable")
    )
    selected_rows = []
    for budget, group in means.groupby("budget_fraction", sort=True):
        # Source criterion: minimize mean validation CI width. Stable sorting
        # supplies a deterministic tie-break without adding a new objective.
        chosen = group.sort_values(
            ["mean_width", "rho", "gamma", "beta0", "tau"], kind="stable"
        ).iloc[0]
        selected_rows.append(chosen)
    selected = pd.DataFrame(selected_rows).reset_index(drop=True)
    write_csv_atomic(selected, out)
    print(selected.to_string(index=False))


def stage_factor_final(ctx: Context, *, force: bool = False, **_: Any) -> None:
    target = ctx.paths["factors"] / "final"
    if all((target / name).is_file() for name in ("U.pt", "V.pt", "metadata.json")) and not force:
        print(f"[skip] {target}")
        return
    sel = _selected_factor(ctx)
    fm = ctx.config["factor_model"]
    fit = fit_logistic_factor_model(
        ctx.data.history_perturbed,
        k=int(sel["k"]),
        weight_decay=float(sel["weight_decay"]),
        learning_rate=float(fm["learning_rate"]),
        max_epochs=int(fm["max_epochs"]),
        seed=int(fm["seed"]),
        device=ctx.device,
    )
    save_factor_fit(
        fit,
        target,
        {
            "source_stage": "factor_models_final.py",
            "training_rows": int(len(ctx.data.history_meta)),
            "k": int(sel["k"]),
            "weight_decay": float(sel["weight_decay"]),
        },
    )


def _factor_accuracy_frame(ctx: Context, fit: FactorFit) -> pd.DataFrame:
    mu0, _ = prior_from_historical_factors(fit.U)
    with torch.no_grad():
        p0 = torch.sigmoid(mu0 @ fit.V.T).cpu().numpy()
    labels = ctx.data.test_values
    accuracy = ((p0[None, :] >= 0.5) == (labels >= 0.5)).mean(axis=1)
    ranks = pd.Series(accuracy).rank(method="first")
    quartile = pd.qcut(
        ranks,
        q=4,
        labels=["Q1_worst", "Q2", "Q3", "Q4_best"],
    ).astype(str)
    return pd.DataFrame(
        {
            "model_index": np.arange(len(labels), dtype=int),
            "model": ctx.data.test_meta["model"].astype(str).to_numpy(),
            "created_date": ctx.data.test_meta["created_date"].astype(str).to_numpy(),
            "true_accuracy": labels.mean(axis=1),
            "initial_factor_prediction_accuracy": accuracy,
            "factor_accuracy_quartile": quartile,
            "is_target_family": ctx.data.target_family_test_mask.astype(bool),
        }
    )


def stage_factor_prediction_accuracy(
    ctx: Context, *, force: bool = False, **_: Any
) -> None:
    out = ctx.paths["results"] / "factor_prediction_accuracy_per_model.csv"
    if out.exists() and (ctx.paths["results"] / "factor_prediction_accuracy_quartiles.csv").exists() and not force:
        print(f"[skip] {out}")
        return
    fit = load_factor_fit(ctx.paths["factors"] / "final")
    frame = _factor_accuracy_frame(ctx, fit)
    write_csv_atomic(frame, out)
    summary = (
        frame.groupby("factor_accuracy_quartile", as_index=False, sort=False)
        .agg(
            n_models=("model_index", "size"),
            mean_prediction_accuracy=("initial_factor_prediction_accuracy", "mean"),
            min_prediction_accuracy=("initial_factor_prediction_accuracy", "min"),
            max_prediction_accuracy=("initial_factor_prediction_accuracy", "max"),
        )
    )
    write_csv_atomic(summary, ctx.paths["results"] / "factor_prediction_accuracy_quartiles.csv")


def _load_factor_accuracy(ctx: Context) -> pd.DataFrame:
    path = ctx.paths["results"] / "factor_prediction_accuracy_per_model.csv"
    if not path.exists():
        stage_factor_prediction_accuracy(ctx)
    return pd.read_csv(path)


def _population_masks(ctx: Context, factor_frame: pd.DataFrame) -> Dict[str, np.ndarray]:
    masks: Dict[str, np.ndarray] = {"all": np.ones(len(factor_frame), dtype=bool)}
    analysis = ctx.spec.get("analysis", {})
    if bool(analysis.get("report_target_family", False)):
        # pandas normally round-trips the CSV boolean column as bool, but parse
        # object-valued strings defensively so that "False" is not treated as
        # truthy merely because it is a non-empty Python string.
        family_col = factor_frame["is_target_family"]
        if family_col.dtype == object:
            family_mask = family_col.astype(str).str.lower().eq("true").to_numpy()
        else:
            family_mask = family_col.astype(bool).to_numpy()
        masks["target_family"] = family_mask
    if bool(analysis.get("factor_accuracy_quartiles", False)):
        for name in ["Q1_worst", "Q2", "Q3", "Q4_best"]:
            masks[name] = factor_frame["factor_accuracy_quartile"].eq(name).to_numpy()
    return {name: mask for name, mask in masks.items() if int(mask.sum()) > 0}


def _aggregate_trial(
    *,
    experiment_id: str,
    budget: float,
    seed: int,
    method: str,
    population_masks: Mapping[str, np.ndarray],
    width: np.ndarray,
    covered: np.ndarray,
    factor_accuracy: np.ndarray,
    extra: Mapping[str, Any],
) -> List[Dict[str, Any]]:
    rows = []
    for population, mask in population_masks.items():
        rows.append(
            {
                "experiment_id": experiment_id,
                "budget_fraction": float(budget),
                "seed": int(seed),
                "method": method,
                "population": population,
                "n_models": int(mask.sum()),
                "mean_width": float(np.mean(width[mask])),
                "coverage": float(np.mean(covered[mask])),
                "mean_initial_factor_prediction_accuracy": float(np.mean(factor_accuracy[mask])),
                **extra,
            }
        )
    return rows


def _selected_faq_map(ctx: Context) -> Dict[float, Dict[str, float]]:
    frame = pd.read_csv(ctx.paths["results"] / "selected_faq_settings.csv")
    return {
        float(row.budget_fraction): {
            "rho": float(row.rho),
            "gamma": float(row.gamma),
            "beta0": float(row.beta0),
            "tau": float(row.tau),
        }
        for row in frame.itertuples(index=False)
    }


def stage_faq_final(
    ctx: Context,
    *,
    task_id: int = 0,
    num_tasks: int = 1,
    force: bool = False,
    **_: Any,
) -> None:
    out = _output_path(ctx, "faq_final", task_id, num_tasks)
    model_out = _output_path(ctx, "faq_final_model_level", task_id, num_tasks)
    save_model_level = bool(ctx.spec.get("analysis", {}).get("save_model_level", False))
    if out.exists() and (not save_model_level or model_out.exists()) and not force:
        print(f"[skip] {out}")
        return
    fit = load_factor_fit(ctx.paths["factors"] / "final")
    mu0, sigma0 = prior_from_historical_factors(fit.U)
    factor_frame = _load_factor_accuracy(ctx)
    factor_accuracy = factor_frame["initial_factor_prediction_accuracy"].to_numpy()
    populations = _population_masks(ctx, factor_frame)
    selected = _selected_faq_map(ctx)
    items = list(
        itertools.product(
            ctx.config["budgets"], range(int(ctx.config["faq"]["final_seeds"]))
        )
    )
    aggregate_rows: List[Dict[str, Any]] = []
    model_frames: List[pd.DataFrame] = []
    for budget, seed in _shard(items, task_id, num_tasks):
        hp = selected[float(budget)]
        result = faq_trial(
            ctx.data.test_values,
            fit.V,
            mu0,
            sigma0,
            budget_fraction=float(budget),
            seed=int(seed),
            alpha=float(ctx.config["alpha"]),
            endpoint_mode=str(ctx.config["faq_interval_endpoint_mode"]),
            device=ctx.device,
            **hp,
        )
        aggregate_rows.extend(
            _aggregate_trial(
                experiment_id=ctx.spec["experiment_id"],
                budget=float(budget),
                seed=int(seed),
                method="FAQ",
                population_masks=populations,
                width=result.width,
                covered=result.covered,
                factor_accuracy=factor_accuracy,
                extra={"n_queries": result.n_queries, **hp},
            )
        )
        if save_model_level:
            model_frames.append(
                pd.DataFrame(
                    {
                        "experiment_id": ctx.spec["experiment_id"],
                        "budget_fraction": float(budget),
                        "seed": int(seed),
                        "model_index": factor_frame["model_index"],
                        "model": factor_frame["model"],
                        "is_target_family": factor_frame["is_target_family"],
                        "factor_accuracy_quartile": factor_frame["factor_accuracy_quartile"],
                        "initial_factor_prediction_accuracy": result.initial_factor_accuracy,
                        "final_factor_prediction_accuracy": result.final_factor_accuracy,
                        "estimate": result.estimate,
                        "standard_error": result.standard_error,
                        "lower": result.lower,
                        "upper": result.upper,
                        "width": result.width,
                        "covered": result.covered,
                        "true_accuracy": result.true_accuracy,
                    }
                )
            )
        print(
            f"[faq-final] budget={budget:.3f} seed={seed} width={result.mean_width:.6f} coverage={result.coverage:.4f}",
            flush=True,
        )
    if save_model_level:
        write_csv_atomic(pd.concat(model_frames, ignore_index=True), model_out)
    write_csv_atomic(pd.DataFrame(aggregate_rows), out)


def _baseline_items(ctx: Context) -> List[Tuple[float, str, float, int]]:
    b = ctx.config["baselines"]
    items: List[Tuple[float, str, float, int]] = []
    for budget in ctx.config["budgets"]:
        for seed in range(int(b["final_seeds"])):
            items.append((float(budget), "unif", 0.0, seed))
            for policy in [p for p in b["policies"] if p != "unif"]:
                for tau in b["taus"]:
                    items.append((float(budget), str(policy), float(tau), seed))
    return items


def stage_baselines(
    ctx: Context,
    *,
    task_id: int = 0,
    num_tasks: int = 1,
    force: bool = False,
    **_: Any,
) -> None:
    out = _output_path(ctx, "baselines", task_id, num_tasks)
    if out.exists() and (ctx.paths["results"] / "historical_question_means_used_by_baselines.csv").exists() and not force:
        print(f"[skip] {out}")
        return
    factor_frame = _load_factor_accuracy(ctx)
    factor_accuracy = factor_frame["initial_factor_prediction_accuracy"].to_numpy()
    populations = _population_masks(ctx, factor_frame)
    # FAIRNESS-CRITICAL: every history-using baseline is rebuilt from the exact
    # same intervened H' supplied to FAQ.  Never substitute history_clean here.
    phats = historical_question_means(ctx.data.history_perturbed)
    write_csv_atomic(
        pd.DataFrame(
            {
                "question": ctx.data.question_columns,
                "historical_mean_used_by_baselines": phats,
            }
        ),
        ctx.paths["results"] / "historical_question_means_used_by_baselines.csv",
    )
    rows: List[Dict[str, Any]] = []
    allowed_predictors = set(ctx.config["baselines"]["predictors"])
    for budget, policy, tau, seed in _shard(_baseline_items(ctx), task_id, num_tasks):
        outputs = baseline_trial(
            ctx.data.test_values,
            phats,
            budget_fraction=float(budget),
            policy=policy,
            tau=float(tau),
            seed=int(seed),
            alpha=float(ctx.config["alpha"]),
            device=ctx.device,
        )
        for predictor, result in outputs.items():
            if predictor not in allowed_predictors:
                continue
            rows.extend(
                _aggregate_trial(
                    experiment_id=ctx.spec["experiment_id"],
                    budget=float(budget),
                    seed=int(seed),
                    method="baseline",
                    population_masks=populations,
                    width=result.width,
                    covered=result.covered,
                    factor_accuracy=factor_accuracy,
                    extra={
                        "policy": policy,
                        "tau": float(tau),
                        "predictor": predictor,
                        "mean_n_labels": float(np.mean(result.n_labels)),
                        "n_queries": budget_count(float(budget), len(ctx.data.question_columns)),
                    },
                )
            )
        print(f"[baseline] budget={budget:.3f} policy={policy} tau={tau} seed={seed}", flush=True)
    write_csv_atomic(pd.DataFrame(rows), out)


def _serr(series: pd.Series) -> float:
    return float(series.std(ddof=1) / math.sqrt(len(series))) if len(series) > 1 else 0.0


def stage_cleaning_results(ctx: Context, *, force: bool = False, **_: Any) -> None:
    out = ctx.paths["results"] / "summary.csv"
    completed_outputs = ["summary.csv", "main_rebuttal_table.csv",
                         "factor_accuracy_stratified_metrics.csv", "per_seed_metrics.csv",
                         "selected_best_baseline.csv"]
    if all((ctx.paths["results"] / name).exists() for name in completed_outputs) and not force:
        print(f"[skip] {out}")
        return
    # Model-level diagnostic logs share the faq_final prefix.  Exclude them
    # before concatenation so a full run never attempts to combine the large
    # per-model table with compact per-seed aggregate rows.
    faq = concat_csvs(
        path
        for path in ctx.paths["logs"].glob("faq_final*.csv")
        if "model_level" not in path.name
    )
    baselines = concat_csvs(ctx.paths["logs"].glob("baselines*.csv"))
    if faq.empty or baselines.empty:
        raise FileNotFoundError("Need faq_final and baselines logs before cleaning.")

    variant_cols = ["budget_fraction", "policy", "tau", "predictor"]
    all_means = (
        baselines.loc[baselines["population"] == "all"]
        .groupby(variant_cols, as_index=False)["mean_width"]
        .mean()
    )
    selected = all_means.loc[
        all_means.groupby("budget_fraction")["mean_width"].idxmin()
    ].reset_index(drop=True)
    write_csv_atomic(selected, ctx.paths["results"] / "selected_best_baseline.csv")
    best = baselines.merge(selected[variant_cols], on=variant_cols, how="inner")
    uniform = baselines.loc[
        (baselines["policy"] == "unif") & (baselines["predictor"] == "zero")
    ].copy()

    join = ["experiment_id", "budget_fraction", "seed", "population"]
    uniform_ref = uniform[join + ["mean_width"]].rename(
        columns={"mean_width": "uniform_mean_width"}
    )

    method_frames: List[pd.DataFrame] = []
    for method_name, frame in (("FAQ", faq), ("Best baseline", best), ("Uniform", uniform)):
        current = frame.copy()
        current["reported_method"] = method_name
        current = current.merge(uniform_ref, on=join, how="left", validate="many_to_one")
        if method_name == "Uniform":
            current["ess_multiplier"] = 1.0
        else:
            current["ess_multiplier"] = (
                current["uniform_mean_width"] / current["mean_width"]
            ).pow(2)
        current["effective_sample_size"] = current.apply(
            lambda row: budget_count(float(row["budget_fraction"]), len(ctx.data.question_columns))
            * float(row["ess_multiplier"]),
            axis=1,
        )
        method_frames.append(current)
    per_seed = pd.concat(method_frames, ignore_index=True)
    write_csv_atomic(per_seed, ctx.paths["results"] / "per_seed_metrics.csv")

    group_cols = ["experiment_id", "budget_fraction", "population", "reported_method"]
    summaries: List[Dict[str, Any]] = []
    for keys, group in per_seed.groupby(group_cols, sort=True):
        row = dict(zip(group_cols, keys))
        row.update(
            {
                "n_seeds": int(group["seed"].nunique()),
                "n_models": int(group["n_models"].iloc[0]),
                "mean_width": float(group["mean_width"].mean()),
                "mean_width_serr": _serr(group["mean_width"]),
                "coverage": float(group["coverage"].mean()),
                "coverage_serr": _serr(group["coverage"]),
                "ess_multiplier": float(group["ess_multiplier"].mean()),
                "ess_multiplier_serr": _serr(group["ess_multiplier"]),
                "effective_sample_size": float(group["effective_sample_size"].mean()),
                "mean_initial_factor_prediction_accuracy": float(
                    group["mean_initial_factor_prediction_accuracy"].mean()
                ),
                "n_queries": int(group["n_queries"].iloc[0]),
            }
        )
        if "policy" in group.columns and group["policy"].notna().any():
            row["policy"] = str(group["policy"].dropna().iloc[0])
            row["tau"] = float(group["tau"].dropna().iloc[0])
            row["predictor"] = str(group["predictor"].dropna().iloc[0])
        summaries.append(row)
    summary = pd.DataFrame(summaries)
    write_csv_atomic(summary, out)

    main = summary.loc[
        summary["population"].isin(["all", "target_family"])
    ].copy()
    write_csv_atomic(main, ctx.paths["results"] / "main_rebuttal_table.csv")
    stratified = summary.loc[
        summary["population"].isin(["Q1_worst", "Q2", "Q3", "Q4_best"])
    ].copy()
    write_csv_atomic(
        stratified, ctx.paths["results"] / "factor_accuracy_stratified_metrics.csv"
    )
    print(summary.to_string(index=False))


STAGE_FUNCTIONS = {
    "prepare_data": stage_prepare_data,
    "factor_cv": stage_factor_cv,
    "analyze_factor_models": stage_analyze_factor_models,
    "factor_val": stage_factor_val,
    "faq_val": stage_faq_val,
    "faq_val_analyzer": stage_faq_val_analyzer,
    "factor_final": stage_factor_final,
    "factor_prediction_accuracy": stage_factor_prediction_accuracy,
    "faq_final": stage_faq_final,
    "baselines": stage_baselines,
    "cleaning_results": stage_cleaning_results,
}

PIPELINE_ORDER = [
    "prepare_data",
    "factor_cv",
    "analyze_factor_models",
    "factor_val",
    "faq_val",
    "faq_val_analyzer",
    "factor_final",
    "factor_prediction_accuracy",
    "faq_final",
    "baselines",
    "cleaning_results",
]
