"""Small file-system helpers for reproducible stage-oriented runs."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


def repo_root_from_experiment(experiment_dir: Path) -> Path:
    """Return the directory that contains ``rebuttal_experiments``."""

    experiment_dir = experiment_dir.resolve()
    if experiment_dir.parent.name != "rebuttal_experiments":
        raise ValueError(
            f"Expected experiment folder directly under rebuttal_experiments; got {experiment_dir}."
        )
    return experiment_dir.parent.parent


def load_experiment_spec(experiment_dir: Path) -> dict[str, Any]:
    path = experiment_dir / "experiment.json"
    if not path.is_file():
        raise FileNotFoundError(f"Missing experiment specification: {path}")
    payload = read_json(path)
    for key in ("experiment_id", "perturbation"):
        if key not in payload:
            raise ValueError(f"{path} must define {key!r}.")
    return payload


def ensure_dirs(experiment_dir: Path, *, smoke: bool) -> dict[str, Path]:
    mode = "smoke" if smoke else "full"
    root = experiment_dir / "artifacts" / mode
    paths = {
        "root": root,
        "logs": root / "logs",
        "results": root / "results",
        "factors": root / "factors",
        "manifests": root / "manifests",
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, indent=2, sort_keys=True, default=_json_default) + "\n"
    _atomic_write_text(path, text)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=path.parent, delete=False
    ) as handle:
        handle.write(text)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_csv_atomic(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=path.parent, delete=False
    ) as handle:
        frame.to_csv(handle, index=False)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def concat_csvs(paths: Iterable[Path]) -> pd.DataFrame:
    materialized = sorted(Path(path) for path in paths)
    if not materialized:
        return pd.DataFrame()
    return pd.concat([pd.read_csv(path) for path in materialized], ignore_index=True)
