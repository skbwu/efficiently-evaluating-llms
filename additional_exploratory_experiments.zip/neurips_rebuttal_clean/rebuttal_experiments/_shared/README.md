# Shared implementation

This directory centralizes the mathematical code so the six fitted rebuttal
conditions cannot silently diverge. Public experiment folders keep the original
repository script names as thin wrappers.

- `factor_model.py`: literal `randn` U/V initialization, full-batch masked
  logistic BCE, AdamW, and the paper's factor hyperparameter grid.
- `faq.py`: the public `faq_final.py` hybrid sampling, PAI estimator, online
  Laplace update, and variance formula, plus model-level logging only.
- `baselines.py`: the public `baselines_all.py` uniform, square-root/Neyman, and
  `2*min(p,1-p)` sequential AIPW procedures.
- `perturbations.py`: the only rebuttal-specific change to historical M1/H.
- `pipeline.py`: original train/CV/validation/final-refit/test/cleaning order.

See `../SOURCE_MAPPING.md` for a line-item map and the endpoint-compatibility
caveat.
