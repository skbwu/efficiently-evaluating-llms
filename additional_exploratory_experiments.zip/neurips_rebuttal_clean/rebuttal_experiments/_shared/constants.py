"""Constants shared by the stitched-suite NeurIPS rebuttal experiments.

Source mapping
--------------
The full settings mirror the public repository's ``factor_models_*.py``,
``faq_val.py``, ``faq_final.py``, ``baselines_all.py``, and
``cleaning_results.py``. Rebuttal-specific changes are limited to the stitched
suite, three requested budgets, deterministic historical-data interventions,
and extra model-level factor-prediction logging.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict

STITCHED_SUITE = "bbh+gpqa+ifeval+math+musr"
STITCHED_SUITE_DISPLAY = "BBH+GPQA+IFEval+MATH+MuSR"
METADATA_COLUMNS = ("model", "created_date", "sha")
ORIGINAL_FACTOR_SEED = 858
PERTURBATION_SEED = 15113

FULL_CONFIG: Dict[str, Any] = {
    "suite": STITCHED_SUITE,
    "suite_display": STITCHED_SUITE_DISPLAY,
    "budgets": [0.025, 0.075, 0.125],
    "alpha": 0.05,
    "train_fraction": 0.80,
    # The public faq_final.py literally uses maximum(raw upper, 0) and
    # minimum(raw lower, 1). Keeping that behavior is necessary for numerical
    # comparability with the submitted paper's logs. A corrected audit mode is
    # implemented separately and never mixed into the main tables.
    "faq_interval_endpoint_mode": "source_exact",
    "factor_model": {
        "dimensions": [8, 16, 32, 64],
        "weight_decays": [10.0, 1.0, 0.1, 0.01, 0.001, 0.0001, 0.00001],
        "learning_rate": 0.01,
        "max_epochs": 2000,
        "cv_folds": 5,
        "seed": ORIGINAL_FACTOR_SEED,
    },
    "faq": {
        "beta0": [0.25, 0.50, 0.75, 1.00],
        "gamma": [0.00, 0.05, 0.25, 0.50, 0.75],
        "rho": [0.00, 0.05, 0.25, 0.50, 0.75],
        "tau": [0.05, 0.25, 0.50, 0.75],
        "validation_seeds": 5,
        "final_seeds": 100,
    },
    "baselines": {
        "policies": ["unif", "sqrt", "2min"],
        "taus": [0.05, 0.25, 0.50, 0.75],
        "predictors": ["zero", "historical_mean"],
        "final_seeds": 100,
    },
    "perturbation_seed": PERTURBATION_SEED,
    "family_selection": {
        "minimum_history_share": 0.05,
        "minimum_test_models": 50,
        "rule": (
            "Among predeclared parent-family regexes satisfying M1 share >= 5% "
            "and M2 count >= 50, maximize M2 count, then M1 count, then use "
            "registry order. Only model-name strings are consulted."
        ),
    },
    "smoke": False,
}

# CPU integration preflight. Equations and stage order are unchanged; only data
# size, grids, epochs, and seeds are reduced. These results are never intended
# as scientific evidence.
SMOKE_OVERRIDES: Dict[str, Any] = {
    "smoke": True,
    "smoke_limits": {
        "history_rows": 96,
        "test_rows": 48,
        "questions": 120,
        "minimum_family_history_rows": 16,
        "minimum_family_test_rows": 16,
    },
    "factor_model": {
        "dimensions": [4, 8],
        "weight_decays": [0.1, 0.01],
        "learning_rate": 0.03,
        "max_epochs": 15,
        "cv_folds": 2,
        "seed": ORIGINAL_FACTOR_SEED,
    },
    "faq": {
        "beta0": [0.50, 1.00],
        "gamma": [0.00, 0.25],
        "rho": [0.00, 0.25],
        "tau": [0.05, 0.25],
        "validation_seeds": 1,
        "final_seeds": 3,
    },
    "baselines": {
        "policies": ["unif", "sqrt", "2min"],
        "taus": [0.05, 0.25],
        "predictors": ["zero", "historical_mean"],
        "final_seeds": 3,
    },
}


def _deep_update(base: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
    out = deepcopy(base)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_update(out[key], value)
        else:
            out[key] = deepcopy(value)
    return out


def get_default_config(*, smoke: bool = False) -> Dict[str, Any]:
    return _deep_update(FULL_CONFIG, SMOKE_OVERRIDES) if smoke else deepcopy(FULL_CONFIG)


# Predeclared metadata-only heuristics. On the supplied M1/M2 matrices the first
# candidate is selected (131 M1 rows, 321 M2 rows).
FAMILY_RULES = [
    {
        "name": "Qwen2.5/QwQ",
        "pattern": r"(?i)(?:qwen[-_ ]?2(?:[._-]?5)(?!\d)|qwq)",
        "rationale": "explicit Qwen2.5 or QwQ parent-family spelling",
    },
    {
        "name": "Llama-3.1",
        "pattern": r"(?i)llama[-_ ]?3(?:[._-]?1)(?!\d)",
        "rationale": "explicit Llama 3.1 parent-family spelling",
    },
    {
        "name": "Gemma-2",
        "pattern": r"(?i)(?:^|[^a-z0-9])gemma[-_ ]?2(?:[^a-z0-9]|$)",
        "rationale": "explicit Gemma 2 parent-family spelling",
    },
]

BENCHMARK_PREFIXES = ("bbh_", "gpqa_", "ifeval_", "math_", "musr_")

# Figure 2 annotations for the fully observed stitched suite at the requested
# budgets. Used only as contextual comparison targets in the smoke report.
PAPER_REFERENCE = {
    0.025: {"faq_ess_multiplier": 3.05, "best_baseline_ess_multiplier": 2.27},
    0.075: {"faq_ess_multiplier": 3.92, "best_baseline_ess_multiplier": 2.27},
    0.125: {"faq_ess_multiplier": 4.21, "best_baseline_ess_multiplier": 2.27},
}
