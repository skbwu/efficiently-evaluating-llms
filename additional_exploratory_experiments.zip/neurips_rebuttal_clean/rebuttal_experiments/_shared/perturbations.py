"""Deterministic historical-data interventions requested by the reviews.

This module is the only place where M1/H is changed. M2 is never altered.
Corruption is applied before the train/validation split for factor fitting and
final historical summaries. During FAQ hyperparameter tuning, labels obtained
by newly querying held-out validation models are read from the clean copy; this
isolates corrupted historical logs from the separate noisy-current-feedback
question about z_{I_t}.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any, Dict, Mapping, Tuple

import numpy as np
import pandas as pd

from .constants import FAMILY_RULES
from .data import BaseData, ExperimentData, apply_smoke_subset, benchmark_counts
from .io_utils import write_csv_atomic, write_json


def family_mask(model_names: pd.Series, pattern: str) -> np.ndarray:
    return model_names.astype(str).str.contains(pattern, regex=True, na=False).to_numpy(dtype=bool)


def select_target_family(base: BaseData, config: Mapping[str, Any]) -> Dict[str, Any]:
    selection = config["family_selection"]
    min_share = float(selection["minimum_history_share"])
    min_test = int(selection["minimum_test_models"])
    candidates: list[Dict[str, Any]] = []
    for order, rule in enumerate(FAMILY_RULES):
        h = family_mask(base.m1_meta["model"], str(rule["pattern"]))
        t = family_mask(base.m2_meta["model"], str(rule["pattern"]))
        row: Dict[str, Any] = {
            "name": str(rule["name"]),
            "pattern": str(rule["pattern"]),
            "rationale": str(rule["rationale"]),
            "registry_order": order,
            "history_count": int(h.sum()),
            "history_share": float(h.mean()),
            "test_count": int(t.sum()),
            "test_share": float(t.mean()),
        }
        row["eligible"] = bool(row["history_share"] >= min_share and row["test_count"] >= min_test)
        candidates.append(row)
    eligible = [row for row in candidates if row["eligible"]]
    if not eligible:
        raise ValueError(f"No predeclared family met the eligibility rule: {candidates}")
    selected = sorted(
        eligible,
        key=lambda row: (-int(row["test_count"]), -int(row["history_count"]), int(row["registry_order"])),
    )[0]
    return {"selected": selected, "candidates": candidates, "selection_rule": str(selection["rule"])}


def _round_half_up(x: float) -> int:
    return int(math.floor(x + 0.5))


def _indices_hash(rows: np.ndarray, cols: np.ndarray, n_questions: int) -> str:
    flat = np.sort(rows.astype(np.int64) * int(n_questions) + cols.astype(np.int64))
    return hashlib.sha256(flat.tobytes()).hexdigest()


def _sample_exact_flips(
    *,
    kind: str,
    base: BaseData,
    family_rows: np.ndarray,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    n_rows, n_questions = base.m1_values.shape
    total = n_rows * n_questions
    k = _round_half_up(0.05 * total)
    rng = np.random.default_rng(seed)
    details: Dict[str, Any] = {
        "requested_global_fraction": 0.05,
        "global_total_entries": int(total),
        "number_flipped": int(k),
        "global_realized_flip_fraction": float(k / total),
        "sampling": "uniform without replacement within the declared eligible block",
        "seed": int(seed),
    }
    if kind == "random_flip_5pct":
        local = rng.choice(total, size=k, replace=False)
        rows = local // n_questions
        cols = local % n_questions
        details.update(
            {
                "eligible_block": "all M1 model-question cells",
                "eligible_entries": int(total),
                "local_flip_fraction": float(k / total),
            }
        )
    elif kind == "benchmark_flip_5pct":
        counts = benchmark_counts(base.question_columns)
        # Predeclared deterministic rule: largest stitched constituent by count;
        # ties use the native column order.
        prefixes = [column.split("_", 1)[0].lower() for column in base.question_columns]
        first_order = {name: prefixes.index(name) for name in set(prefixes)}
        benchmark = sorted(counts, key=lambda name: (-counts[name], first_order[name]))[0]
        prefix = benchmark + "_"
        eligible_cols = np.array([i for i, c in enumerate(base.question_columns) if c.startswith(prefix)], dtype=np.int64)
        eligible = n_rows * len(eligible_cols)
        if k > eligible:
            raise ValueError(f"Need {k} benchmark flips but only {eligible} cells are eligible.")
        local = rng.choice(eligible, size=k, replace=False)
        rows = local // len(eligible_cols)
        cols = eligible_cols[local % len(eligible_cols)]
        details.update(
            {
                "eligible_block": f"all M1 rows x {benchmark} question columns",
                "benchmark": benchmark,
                "benchmark_question_count": int(len(eligible_cols)),
                "eligible_entries": int(eligible),
                "local_flip_fraction": float(k / eligible),
                "benchmark_counts": counts,
            }
        )
    elif kind == "family_flip_5pct":
        eligible_rows = np.flatnonzero(family_rows)
        eligible = len(eligible_rows) * n_questions
        if k > eligible:
            raise ValueError(f"Need {k} family flips but only {eligible} cells are eligible.")
        local = rng.choice(eligible, size=k, replace=False)
        rows = eligible_rows[local // n_questions]
        cols = local % n_questions
        details.update(
            {
                "eligible_block": "selected-family M1 rows x all question columns",
                "eligible_history_rows": int(len(eligible_rows)),
                "eligible_entries": int(eligible),
                "local_flip_fraction": float(k / eligible),
            }
        )
    else:
        raise ValueError(f"Unsupported corruption kind {kind!r}")
    rows = rows.astype(np.int64, copy=False)
    cols = cols.astype(np.int64, copy=False)
    details["flip_indices_sha256"] = _indices_hash(rows, cols, n_questions)
    return rows, cols, details


def _write_family_audits(
    manifest_dir: Path,
    selection: Mapping[str, Any],
    base: BaseData,
    history_mask: np.ndarray,
    test_mask: np.ndarray,
) -> None:
    write_csv_atomic(pd.DataFrame(selection["candidates"]), manifest_dir / "family_candidate_counts.csv")
    base.m1_meta.loc[history_mask].to_csv(manifest_dir / "matched_family_history_models.csv", index=False)
    base.m2_meta.loc[test_mask].to_csv(manifest_dir / "matched_family_test_models.csv", index=False)


def prepare_experiment_data(
    full_base: BaseData,
    spec: Mapping[str, Any],
    config: Mapping[str, Any],
    manifest_dir: Path,
) -> ExperimentData:
    """Select family on full metadata, optionally smoke-subset, then intervene."""
    selection = select_target_family(full_base, config)
    selected = selection["selected"]
    full_hmask = family_mask(full_base.m1_meta["model"], selected["pattern"])
    full_tmask = family_mask(full_base.m2_meta["model"], selected["pattern"])
    _write_family_audits(manifest_dir, selection, full_base, full_hmask, full_tmask)

    base = full_base
    if bool(config.get("smoke")):
        base = apply_smoke_subset(
            full_base,
            target_pattern=str(selected["pattern"]),
            limits=config["smoke_limits"],
        )

    hmask = family_mask(base.m1_meta["model"], selected["pattern"])
    tmask = family_mask(base.m2_meta["model"], selected["pattern"])
    kind = str(spec["perturbation"])
    clean = base.m1_values.copy()
    perturbed = clean.copy()
    history_meta = base.m1_meta.copy().reset_index(drop=True)
    available_original_indices = base.original_m1_indices.copy()
    details: Dict[str, Any] = {}

    if kind == "clean":
        details["mathematical_intervention"] = "H' = H"
    elif kind == "family_absent":
        keep = ~hmask
        clean = clean[keep]
        perturbed = perturbed[keep]
        history_meta = history_meta.loc[keep].reset_index(drop=True)
        available_original_indices = available_original_indices[keep]
        hmask = np.zeros(len(history_meta), dtype=bool)
        details.update(
            {
                "removed_history_rows": int((~keep).sum()),
                "retained_history_rows": int(keep.sum()),
                "mathematical_intervention": (
                    "All selected-family H rows are unavailable before splitting. "
                    "Dropping them is likelihood-equivalent to setting every cell in those rows to NA, "
                    "and avoids arbitrary all-missing row factors entering the prior."
                ),
            }
        )
    elif kind == "recent_half_absent":
        dates = pd.to_datetime(history_meta["created_date"], errors="coerce", utc=True)
        if dates.isna().any():
            raise ValueError("Temporal experiment requires parseable created_date for every M1 row.")
        order = np.argsort(dates.to_numpy(), kind="stable")
        n_keep = len(order) // 2
        keep_idx = order[:n_keep]
        clean = clean[keep_idx]
        perturbed = perturbed[keep_idx]
        history_meta = history_meta.iloc[keep_idx].reset_index(drop=True)
        available_original_indices = available_original_indices[keep_idx]
        hmask = family_mask(history_meta["model"], selected["pattern"])
        details.update(
            {
                "retained_oldest_rows": int(n_keep),
                "removed_newest_rows": int(len(order) - n_keep),
                "last_retained_date": str(history_meta.iloc[-1]["created_date"]),
                "mathematical_intervention": (
                    "Stable-sort M1 by release date and retain rows 0,...,floor(N/2)-1 only."
                ),
            }
        )
    elif kind in {"random_flip_5pct", "benchmark_flip_5pct", "family_flip_5pct"}:
        if np.isnan(clean).any():
            raise ValueError("Corruption experiments are defined on fully observed M1.")
        rows, cols, details = _sample_exact_flips(
            kind=kind,
            base=base,
            family_rows=hmask,
            seed=int(config["perturbation_seed"]),
        )
        perturbed[rows, cols] = 1.0 - perturbed[rows, cols]
        np.savez(
            manifest_dir / "corruption_indices.npz",
            row=rows,
            col=cols,
            original_m1_row=base.original_m1_indices[rows],
            original_question_index=base.original_question_indices[cols],
        )
        preview_n = min(100, len(rows))
        preview = pd.DataFrame(
            {
                "working_row": rows[:preview_n],
                "working_col": cols[:preview_n],
                "original_m1_row": base.original_m1_indices[rows[:preview_n]],
                "original_question_index": base.original_question_indices[cols[:preview_n]],
                "model": base.m1_meta.iloc[rows[:preview_n]]["model"].to_numpy(),
                "question": np.array(base.question_columns, dtype=object)[cols[:preview_n]],
            }
        )
        write_csv_atomic(preview, manifest_dir / "corruption_preview_first100.csv")
        details["mathematical_intervention"] = (
            "For the exact selected set S, H'_{ij}=1-H_{ij} for (i,j) in S and H'_{ij}=H_{ij} otherwise."
        )
    else:
        raise ValueError(f"Unknown perturbation {kind!r}")

    manifest: Dict[str, Any] = {
        "experiment_id": str(spec["experiment_id"]),
        "perturbation": kind,
        "smoke": bool(config.get("smoke")),
        "m1_path": str(full_base.m1_path),
        "m2_path": str(full_base.m2_path),
        "full_shape_m1": list(full_base.m1_values.shape),
        "full_shape_m2": list(full_base.m2_values.shape),
        "working_shape_before_row_intervention": list(base.m1_values.shape),
        "working_history_rows_after_intervention": int(len(history_meta)),
        "working_test_rows": int(len(base.m2_meta)),
        "working_questions": int(len(base.question_columns)),
        "benchmark_counts_working": benchmark_counts(base.question_columns),
        "selected_family": selected,
        "family_selection_rule": selection["selection_rule"],
        "selected_family_full_history_count": int(full_hmask.sum()),
        "selected_family_full_test_count": int(full_tmask.sum()),
        "selected_family_working_history_count_before_intervention": int(
            family_mask(base.m1_meta["model"], selected["pattern"]).sum()
        ),
        "selected_family_working_test_count": int(tmask.sum()),
        "m2_untouched": True,
        "fresh_validation_queries_use_clean_labels": True,
        "available_original_m1_indices_sha256": hashlib.sha256(
            available_original_indices.astype(np.int64).tobytes()
        ).hexdigest(),
        **details,
    }
    write_json(manifest_dir / "intervention_manifest.json", manifest)
    write_csv_atomic(
        pd.DataFrame({"working_history_row": np.arange(len(history_meta)), "original_m1_row": available_original_indices}),
        manifest_dir / "available_history_row_mapping.csv",
    )
    write_csv_atomic(
        pd.DataFrame({
            "working_question": np.arange(len(base.question_columns)),
            "original_question_index": base.original_question_indices,
            "question": base.question_columns,
        }),
        manifest_dir / "question_mapping.csv",
    )

    return ExperimentData(
        history_meta=history_meta,
        history_clean=clean,
        history_perturbed=perturbed,
        test_meta=base.m2_meta.reset_index(drop=True),
        test_values=base.m2_values.copy(),
        question_columns=list(base.question_columns),
        target_family_history_mask=hmask,
        target_family_test_mask=tmask,
        target_family=dict(selected),
        manifest=manifest,
    )
