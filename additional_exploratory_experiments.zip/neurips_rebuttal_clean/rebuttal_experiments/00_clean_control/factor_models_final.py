#!/usr/bin/env python3
"""Run factor_models_final through the shared experiment pipeline. See SOURCE_MAPPING.md."""
from pathlib import Path

from rebuttal_experiments._shared.cli import main_for_stage


if __name__ == "__main__":
    main_for_stage(Path(__file__).resolve().parent, "factor_final")
