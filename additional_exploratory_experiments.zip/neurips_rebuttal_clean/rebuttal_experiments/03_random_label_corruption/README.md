# 03 — Globally random 5% historical-label corruption

## Reviewer target

This directly answers the request for robustness to noisy or incorrectly scored
historical outcomes. The corruption acts only on historical M1/H; newly queried
validation outcomes and all M2 test outcomes remain clean.

## Exact intervention

The full stitched historical matrix has

```text
N_old = 2,211
N_q   = 9,574
N     = N_old * N_q = 21,168,114 cells.
```

Set

\[
K=\left\lfloor 0.05N+\tfrac12\right\rfloor=1{,}058{,}406.
\]

Using NumPy's `default_rng(seed=15113)`, sample exactly `K` distinct flattened
indices uniformly without replacement from `{0,...,N-1}`. Convert each flat
index `a` to

```text
row = a // N_q
col = a % N_q
```

and switch the binary label:

\[
H'_{ij}=\begin{cases}
1-H_{ij}, &(i,j)\in S,\\
H_{ij}, &\text{otherwise}.
\end{cases}
\]

The realized global rate is `1,058,406 / 21,168,114 = 0.05000001417`.
The exact row/column arrays, original source indices, a SHA-256 hash, and a
100-cell preview are written under `artifacts/{mode}/manifests/`.

Corruption is applied **before** the 80/20 historical row split, so factor CV,
FAQ validation fitting, hyperparameter selection, final refitting, and
historical baseline summaries all inherit the corrupted log. The underlying
clean copy of held-out historical validation rows is used only when FAQ
simulates a fresh query during tuning. This preserves the intended distinction
between corrupted history and noisy current feedback.

## Pipeline held fixed

1. Split M1 rows chronologically: first 80% for factor/FAQ training and final
   20% for held-out FAQ validation.
2. Run five-fold flattened-entry CV on the corrupted `H'_train` over
   `k={8,16,32,64}` and
   `lambda={10,1,.1,.01,.001,1e-4,1e-5}`. Use AdamW, learning rate 0.01,
   2,000 epochs, and seed 858; apply the paper's one-standard-error rule.
3. Refit on corrupted `H'_train` and tune the complete submitted FAQ grid at
   2.5%, 7.5%, and 12.5% using five validation seeds and minimum mean CI width.
4. Refit the selected factor model on all corrupted M1 rows.
5. Evaluate FAQ and every submitted AIPW baseline variant on clean M2 with
   100 seeds.
6. Select the strongest baseline post hoc by all-M2 mean width, separately by
   budget, exactly as in the submitted workflow.

## Metrics

Report the paper's existing empirical 95% coverage, mean CI width, ESS, and ESS
multiplier relative to uniform:

```text
ESS multiplier = (uniform mean width / method mean width)^2
ESS            = n_b * ESS multiplier
```

Binary pre-query factor-prediction accuracy is logged as the sole additional
diagnostic; it is never used for tuning or sampling.

## Baseline fairness

All history-using methods see the **same corrupted matrix** `H'`. In particular,

```text
p_bar_j = mean_i H'_{ij}
```

is recomputed from the switched labels and used by both the historical-mean
AIPW predictor and the `sqrt(p_bar_j(1-p_bar_j))` / `2min(...)` policies. No
baseline can use clean M1. Uniform is unchanged because it does not use M1. FAQ
and every baseline are evaluated on the same untouched M2 labels.

## Run

```bash
# Uses the bundled data/M1.csv and data/M2.csv.
FAQ_DEVICE=cuda bash rebuttal_experiments/03_random_label_corruption/run_full_pipeline.sh
```

CPU integration preflight:

```bash
FAQ_DEVICE=cpu bash rebuttal_experiments/03_random_label_corruption/run_smoke_test.sh
```

Smoke mode tests code paths only; its tiny matrices, 15 factor epochs, and three
seeds are not rebuttal evidence.
