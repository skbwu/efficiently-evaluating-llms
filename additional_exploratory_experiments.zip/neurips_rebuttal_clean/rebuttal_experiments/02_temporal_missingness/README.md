# 02 — Newest half of historical models absent

## Reviewer target

This is the release-date/stale-history stress test requested for systematic
historical missingness. It deliberately removes the entire recent historical
cohort rather than sweeping several truncation rates.

## Exact intervention

Parse `created_date`, stable-sort M1 in ascending release-date order, and keep
only

```text
H' = H[0 : floor(2211/2), :] = H[0:1105, :].
```

The newest 1,106 rows are unavailable before CV or tuning. The retained 1,105
oldest rows split into 884 train and 221 validation rows. M2 and all 9,574
questions remain unchanged. Report the paper metrics on all M2 models.

## Pipeline held fixed

This folder intentionally keeps the submitted pipeline rather than introducing a
new rebuttal implementation:

1. Apply the declared intervention to M1 **before** splitting.
2. Preserve chronological row order and split available M1 rows into the first
   80% for `H_train` and the last 20% for `H_val`.
3. On `H_train`, run five-fold entrywise CV over
   `k in {8,16,32,64}` and AdamW weight decay
   `lambda in {10,1,.1,.01,.001,1e-4,1e-5}`; learning rate is 0.01,
   maximum epochs 2,000, and initialization seed 858. Select the smallest `k`,
   then strongest regularization, among settings within one standard error of
   the best binary prediction accuracy.
4. Refit the selected factor model on all of `H_train`; tune FAQ separately at
   2.5%, 7.5%, and 12.5% over the complete submitted grid:
   `beta0={.25,.5,.75,1}`, `gamma={0,.05,.25,.5,.75}`,
   `rho={0,.05,.25,.5,.75}`, `tau={.05,.25,.5,.75}`. Use five validation
   seeds and select minimum mean CI width.
5. Refit the selected factor model on all available perturbed M1 rows. Evaluate
   M2 with 100 FAQ seeds and 100 baseline seeds.
6. Re-run the submitted uniform, square-root/Neyman, and
   `2*min(p,1-p)` AIPW baselines, both predictors (`0` and historical question
   mean), and the submitted tau grid. Select the strongest baseline post hoc by
   mean width over all M2 models, separately by budget, exactly as in
   `cleaning_results.py`.

Historical corruption affects factor fitting, final historical question means,
and final refitting. During FAQ tuning, outcomes obtained by newly querying
held-out validation models are taken from the clean underlying matrix. This
isolates corrupted historical logs from the separate reviewer question about
noisy *current* feedback `z_{I_t}`.

## Metrics (same as the paper)

The primary outputs are empirical 95% CI coverage, mean 95% CI width, effective
sample size (ESS), and ESS multiplier relative to uniform. At each seed,

```text
ESS multiplier = (uniform mean width / method mean width)^2,
ESS            = n_b * ESS multiplier.
```

The post-hoc best baseline is selected on the all-M2 population and the same
selected variant is reused for every subgroup. The only added diagnostic is
binary factor-prediction accuracy, which is already the paper's factor-CV
metric. No Brier score or new efficiency definition is introduced.

The main mode is `source_exact`: it preserves the two endpoint operations in the
public `faq_final.py`, so widths and ESS are comparable to the submitted logs.
`corrected_clip` exists only as a separately labeled audit.

## Run

```bash
# from repository root
# Uses the bundled data/M1.csv and data/M2.csv.
FAQ_DEVICE=cuda bash rebuttal_experiments/02_temporal_missingness/run_full_pipeline.sh
```

For a CPU integration preflight:

```bash
FAQ_DEVICE=cpu bash rebuttal_experiments/02_temporal_missingness/run_smoke_test.sh
```

Smoke mode uses 96 M1 rows, 48 M2 rows, 120 questions, 15 factor epochs,
reduced grids, one validation seed, and three final seeds. It tests code paths
only and must not be quoted as scientific evidence.

## Outputs

`artifacts/full/` contains the resolved configuration, exact intervention
manifest and hashes, factor CV/tuning/final logs, per-seed FAQ and baseline
metrics, `summary.csv`, `main_rebuttal_table.csv`, and—where requested—model-
level factor-accuracy/FAQ logs. Every random choice is seeded and every row or
cell intervention is auditable.

## Baseline fairness

All history-using methods see the **same** intervened matrix `H'` in this
condition. In particular,

```text
p_bar_j = mean of the observed H'_{ij} values over available historical rows i
```

is recomputed from `H'` and is used by both the historical-mean AIPW predictor
and the `sqrt(p_bar_j(1-p_bar_j))` / `2min(p_bar_j,1-p_bar_j)` sampling rules.
No baseline has access to the clean pre-intervention M1. Uniform sampling is
unchanged because it uses no historical data. All methods are evaluated on the
same untouched M2 labels. The strongest baseline variant is selected post hoc
on all M2 models separately at each budget, as in the submitted paper; that
selection deliberately favors the baselines.
