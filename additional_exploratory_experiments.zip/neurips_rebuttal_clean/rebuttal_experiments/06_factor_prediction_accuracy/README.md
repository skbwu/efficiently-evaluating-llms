# 06 — Factor-prediction-accuracy stratification

## Reviewer target

This is the text-only answer to the request to understand empirical efficiency
under factor-model misspecification. It adds no synthetic generator, factor-rank
sweep, or new performance metric.

## Exact diagnostic

Experiments 00 and 01 each fit the full selected historical factor model and
initialize a new M2 model with

```text
mu0 = (1/N_history) sum_i U_i,
p_j^(0) = sigmoid(mu0^T V_j).
```

For M2 model `r` with clean fixed labels `z_rj`, before any query compute the
same binary accuracy used in factor CV:

```text
A_r = (1/N_q) sum_j 1{ 1[p_j^(0) >= 0.5] = z_rj }.
```

Stable-rank all 2,212 models by `A_r`, then use `pandas.qcut` to form four
equal-count groups: `Q1_worst`, `Q2`, `Q3`, `Q4_best`. Prediction accuracy is
post-hoc diagnostic information only; it is never used for factor selection,
FAQ tuning, sampling, baseline selection, or exclusion.

Within each quartile, report the paper's existing metrics—coverage, mean CI
width, ESS, and ESS multiplier—for FAQ, the single all-M2-selected strongest
baseline, and uniform. Do this for clean history and for the severe
Qwen2.5/QwQ-absent condition. All requested budgets are saved; the rebuttal
text table emphasizes 7.5%.

## Run

First complete experiments 00 and 01, then:

```bash
python rebuttal_experiments/06_factor_prediction_accuracy/factor_prediction_accuracy.py --mode full
```

Outputs are CSV and Markdown tables under `artifacts/full/results/`.
