#!/usr/bin/env python3
"""Aggregate factor-accuracy results from completed experiments 00 and 01."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["smoke", "full"], default="full")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    root = here.parent
    outdir = here / "artifacts" / args.mode / "results"
    outdir.mkdir(parents=True, exist_ok=True)
    combined_path = outdir / "factor_accuracy_clean_vs_family_absent.csv"
    outputs = [combined_path, outdir / "factor_accuracy_7p5pct_text_table.csv",
               outdir / "factor_accuracy_7p5pct_text_table.md"]
    if all(path.exists() for path in outputs) and not args.force:
        print(f"[skip] {combined_path}")
        return

    frames = []
    for experiment, label in [
        ("00_clean_control", "Clean history"),
        ("01_family_missingness", "Qwen2.5/QwQ absent"),
    ]:
        path = root / experiment / "artifacts" / args.mode / "results" / "factor_accuracy_stratified_metrics.csv"
        if not path.exists():
            raise FileNotFoundError(
                f"Missing {path}. Run {experiment}/run_{'smoke_test' if args.mode == 'smoke' else 'full_pipeline'}.sh first."
            )
        frame = pd.read_csv(path)
        frame.insert(0, "condition", label)
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    combined.to_csv(combined_path, index=False)

    primary = combined.loc[
        combined["budget_fraction"].round(6).eq(0.075),
        [
            "condition",
            "population",
            "reported_method",
            "n_models",
            "mean_initial_factor_prediction_accuracy",
            "coverage",
            "mean_width",
            "ess_multiplier",
            "effective_sample_size",
        ],
    ].copy()
    order = {"Q1_worst": 1, "Q2": 2, "Q3": 3, "Q4_best": 4}
    primary["quartile_order"] = primary["population"].map(order)
    primary = primary.sort_values(
        ["condition", "quartile_order", "reported_method"], kind="stable"
    ).drop(columns="quartile_order")
    csv_path = outdir / "factor_accuracy_7p5pct_text_table.csv"
    md_path = outdir / "factor_accuracy_7p5pct_text_table.md"
    primary.to_csv(csv_path, index=False)
    md_path.write_text(primary.to_markdown(index=False) + "\n")
    print(primary.to_string(index=False))


if __name__ == "__main__":
    main()
