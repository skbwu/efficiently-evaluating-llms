#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT"
"${PYTHON:-python3}" rebuttal_experiments/06_factor_prediction_accuracy/factor_prediction_accuracy.py --mode smoke "$@"
