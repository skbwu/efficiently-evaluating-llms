#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT"
"${PYTHON:-python3}" -m rebuttal_experiments._shared.cli \
  --experiment-dir "rebuttal_experiments/04_benchmark_label_corruption" \
  --all \
  --device "${FAQ_DEVICE:-cuda}" "$@"
