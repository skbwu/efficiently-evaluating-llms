#!/usr/bin/env python3
"""Check scientific invariants and outputs of fresh smoke runs on bundled inputs."""
from __future__ import annotations

import math
from pathlib import Path
import tempfile

import numpy as np
import pandas as pd
import torch

from rebuttal_experiments._shared.baselines import historical_question_means
from rebuttal_experiments._shared.constants import get_default_config
from rebuttal_experiments._shared.data import apply_smoke_subset, load_base_data
from rebuttal_experiments._shared.io_utils import read_json
from rebuttal_experiments._shared.perturbations import prepare_experiment_data, select_target_family

EXPERIMENTS = [
    "00_clean_control", "01_family_missingness", "02_temporal_missingness",
    "03_random_label_corruption", "04_benchmark_label_corruption", "05_family_label_corruption",
]


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    root = Path(__file__).resolve().parent.parent
    config = get_default_config(smoke=True)
    base = load_base_data(root, {})
    family = select_target_family(base, config)["selected"]
    subset = apply_smoke_subset(base, target_pattern=family["pattern"], limits=config["smoke_limits"])
    original_test = subset.m2_values.copy()
    for name in EXPERIMENTS:
        exp = root / "rebuttal_experiments" / name
        spec = read_json(exp / "experiment.json")
        art = exp / "artifacts" / "smoke"
        # Rebuild in a temporary folder so verification does not overwrite run evidence.
        with tempfile.TemporaryDirectory() as tmp:
            audit = Path(tmp)
            data = prepare_experiment_data(base, spec, config, audit)
            row_map = pd.read_csv(audit / "available_history_row_mapping.csv")["original_m1_row"].to_numpy()
            expected_clean = base.m1_values[np.ix_(row_map, subset.original_question_indices)]
            check(np.array_equal(data.history_clean, expected_clean), f"{name}: clean history changed")
            check(np.array_equal(data.test_values, original_test), f"{name}: clean M2 changed")
            pd.testing.assert_frame_equal(data.test_meta, subset.m2_meta)
            changed = data.history_clean != data.history_perturbed
            kind = spec["perturbation"]
            if kind.endswith("flip_5pct"):
                expected_count = math.floor(0.05 * subset.m1_values.size + 0.5)
                check(int(changed.sum()) == expected_count, f"{name}: wrong flip count")
                check(np.array_equal(data.history_perturbed[changed], 1 - data.history_clean[changed]),
                      f"{name}: flipped values are incorrect")
                if kind == "benchmark_flip_5pct":
                    cols = [q.startswith('bbh_') for q in data.question_columns]
                    check(not changed[:, ~np.asarray(cols)].any(), f"{name}: flips outside BBH")
                if kind == "family_flip_5pct":
                    check(not changed[~data.target_family_history_mask].any(), f"{name}: flips outside family")
                with np.load(art / "manifests" / "corruption_indices.npz") as saved, np.load(audit / "corruption_indices.npz") as expected:
                    for key in expected.files:
                        check(np.array_equal(saved[key], expected[key]), f"{name}: saved flip indices differ")
            else:
                check(not changed.any(), f"{name}: unexpected label changes")
            if kind == "family_absent":
                check(not data.history_meta['model'].str.contains(family['pattern'], regex=True).any(),
                      f"{name}: family rows remain")
                check(len(data.history_meta) == 80, f"{name}: wrong retained family-absent count")
            if kind == "recent_half_absent":
                order = np.argsort(pd.to_datetime(subset.m1_meta['created_date'], utc=True).to_numpy(), kind='stable')
                check(np.array_equal(row_map, subset.original_m1_indices[order[:48]]),
                      f"{name}: retained rows are not the oldest half")
            means = pd.read_csv(art / "results" / "historical_question_means_used_by_baselines.csv")
            np.testing.assert_allclose(means['historical_mean_used_by_baselines'],
                                       historical_question_means(data.history_perturbed), rtol=0, atol=1e-7)
            check(means['question'].tolist() == data.question_columns, f"{name}: question order changed")
            for fit_name, rows in [('validation', int(0.8 * len(data.history_meta))), ('final', len(data.history_meta))]:
                factors = art / "factors" / fit_name
                u = torch.load(factors / "U.pt", map_location='cpu', weights_only=True)
                v = torch.load(factors / "V.pt", map_location='cpu', weights_only=True)
                check(u.shape[0] == rows and v.shape == (120, u.shape[1]), f"{name}: factor dimensions")
                check(bool(torch.isfinite(u).all() and torch.isfinite(v).all()), f"{name}: nonfinite factors")
                read_json(factors / "metadata.json")
        summary = pd.read_csv(art / "results" / "summary.csv")
        check(set(summary['reported_method']) == {'FAQ', 'Best baseline', 'Uniform'}, f"{name}: missing methods")
        check(set(summary['n_queries']) == {3, 9, 15}, f"{name}: wrong smoke budgets")
        check(summary['n_seeds'].eq(3).all(), f"{name}: missing seeds")
        check(summary['coverage'].between(0, 1).all(), f"{name}: invalid coverage")
        for col in ['mean_width', 'coverage', 'ess_multiplier', 'effective_sample_size']:
            check(np.isfinite(summary[col]).all(), f"{name}: nonfinite {col}")
        check(summary.loc[summary['reported_method'].eq('Uniform'), 'ess_multiplier'].eq(1).all(),
              f"{name}: wrong uniform ESS")
        main = pd.read_csv(art / "results" / "main_rebuttal_table.csv")
        pd.testing.assert_frame_equal(main, summary.loc[summary['population'].isin(['all', 'target_family'])].reset_index(drop=True))
        if spec.get('analysis', {}).get('save_model_level'):
            models = pd.read_csv(art / 'logs' / 'faq_final_model_level.csv')
            check(len(models) == 3 * 3 * 48, f"{name}: incomplete model-level log")
        print(f"[ok] {name}: intervention, clean M2, baseline fairness, factors, budgets, seeds, results")
    analysis = root / 'rebuttal_experiments/06_factor_prediction_accuracy/artifacts/smoke/results'
    combined = pd.read_csv(analysis / 'factor_accuracy_clean_vs_family_absent.csv')
    check(len(combined) == 2 * 3 * 4 * 3, 'Incomplete factor-accuracy aggregation')
    text = pd.read_csv(analysis / 'factor_accuracy_7p5pct_text_table.csv')
    check(len(text) == 2 * 4 * 3, 'Incomplete 7.5% factor-accuracy table')
    check((analysis / 'factor_accuracy_7p5pct_text_table.md').stat().st_size > 0, 'Missing text table')
    print('[ok] 06_factor_prediction_accuracy: both conditions and all quartiles/methods')


if __name__ == '__main__':
    main()
