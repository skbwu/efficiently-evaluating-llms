# Source mapping and rebuttal-only changes

The goal is to modify the public code minimally while avoiding six independent
copies of the same numerical implementation.

| Public repository source | Shared implementation | Rebuttal-only changes |
|---|---|---|
| `factor_models_cv.py` | `_shared/factor_model.py`, `_shared/pipeline.py::stage_factor_cv` | choose one intervention before the 80/20 split; budgets irrelevant; save auditable logs |
| `analyzing_factor_models.py` | `_shared/factor_model.py::select_factor_setting_one_se` | none beyond experiment-specific logs |
| `factor_models_val.py` | `_shared/pipeline.py::stage_factor_val` | train on intervened `H_train` |
| `faq_val.py` | `_shared/faq.py`, `_shared/pipeline.py::stage_faq_val` | budgets `{.025,.075,.125}`; clean fresh labels for queried held-out validation rows |
| `faq_val_analyzer.py` | `_shared/pipeline.py::stage_faq_val_analyzer` | none; minimize mean validation CI width |
| `factor_models_final.py` | `_shared/pipeline.py::stage_factor_final` | refit on all available intervened M1 |
| `faq_final.py` | `_shared/faq.py`, `_shared/pipeline.py::stage_faq_final` | extra model-level factor-prediction logging; same FAQ/PAI equations |
| `baselines_all.py` | `_shared/baselines.py`, `_shared/pipeline.py::stage_baselines` | historical means are recomputed from the exact same intervened M1 |
| `cleaning_results.py` | `_shared/pipeline.py::stage_cleaning_results` | subgroup and factor-accuracy tables; same post-hoc baseline selection principle |
| `faq_coverage_analysis.py` | `_shared/pipeline.py::stage_factor_prediction_accuracy` | pre-query binary factor-accuracy quartiles |
| `missingness_data_generator.py` | `_shared/perturbations.py` | deterministic family/date missingness and exact-count corruption |

## Numerical details retained

- U and V are initialized with `torch.randn` after seed 858.
- Logistic matrix factorization uses full-batch masked BCE-with-logits and
  AdamW, learning rate 0.01, up to 2,000 epochs.
- Factor grid: `k={8,16,32,64}` and
  `lambda={10,1,.1,.01,.001,1e-4,1e-5}`.
- The flattened-entry five-fold split mirrors the public
  `KFold(n_splits=5, shuffle=True, random_state=858)` and is then intersected
  with the observed-entry mask.
- FAQ grid and five validation seeds are unchanged.
- Final FAQ and baseline evaluation uses 100 seeds.
- Baseline policy/predictor/tau grids are unchanged.
- FAQ samples with replacement and uses the submitted PAI estimator, variance
  accumulator, online Laplace update, and hybrid policy.

## Endpoint compatibility note

The public `faq_final.py` literally applies

```python
upper = maximum(raw_upper, 0)
lower = minimum(raw_lower, 1)
```

rather than conventional clipping. Main runs preserve that source behavior in
`source_exact` mode so clean-control numbers can be compared to the paper.
`corrected_clip` is available only as a separately labeled audit and must not be
mixed into the main rebuttal table.
