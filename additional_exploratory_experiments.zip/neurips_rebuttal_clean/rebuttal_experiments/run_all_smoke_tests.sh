#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
export FAQ_DEVICE="${FAQ_DEVICE:-cpu}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
for experiment in \
  00_clean_control \
  01_family_missingness \
  02_temporal_missingness \
  03_random_label_corruption \
  04_benchmark_label_corruption \
  05_family_label_corruption; do
  echo "=== smoke: ${experiment} ==="
  bash "rebuttal_experiments/${experiment}/run_smoke_test.sh" "$@"
done
bash rebuttal_experiments/06_factor_prediction_accuracy/run_smoke_test.sh "$@"
"${PYTHON:-python3}" -m rebuttal_experiments.verify_smoke_artifacts
