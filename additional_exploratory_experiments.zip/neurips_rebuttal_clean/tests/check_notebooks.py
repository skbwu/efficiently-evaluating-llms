#!/usr/bin/env python3
"""Execute the packaged notebook cells in CPU smoke mode from a fresh ZIP.

Only Google Drive mounting is substituted with a local directory. All setup,
extraction, subprocess launch, stage backups, aggregation and display cells run.
This does not test Google's authentication, remote Drive, CUDA, or a hosted VM.
"""
from pathlib import Path
import argparse
import ast
import json
import os
import subprocess
import sys
import tempfile
import types
import zipfile


def execute_one(notebook, archive, work, backup):
    drive = types.SimpleNamespace(mount=lambda path: print('[test] using a local Drive directory'))
    google = sys.modules.setdefault('google', types.ModuleType('google'))
    colab = types.ModuleType('google.colab')
    colab.drive = drive
    google.colab = colab
    sys.modules['google.colab'] = colab
    namespace = {'__name__': '__main__'}
    for index, cell in enumerate(json.loads(notebook.read_text())['cells']):
        if cell['cell_type'] != 'code':
            continue
        exec(compile(''.join(cell['source']), f'{notebook.name}:cell-{index}', 'exec'), namespace)
        if index == 1:
            namespace.update(MODE='smoke', DEVICE='cpu', FORCE=False,
                             DRIVE_INPUT_DIR=str(archive.parent), ZIP_FILENAME=archive.name,
                             WORK_DIR=str(work), DRIVE_RUN_ROOT=str(backup))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--one', type=Path)
    parser.add_argument('--work', type=Path)
    parser.add_argument('--backup', type=Path)
    args = parser.parse_args()
    if args.one:
        execute_one(args.one.resolve(), args.archive.resolve(), args.work.resolve(), args.backup.resolve())
        return
    archive = args.archive.resolve()
    script = Path(__file__).resolve()
    env = dict(os.environ, OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    for key in ['FAQ_M1_PATH', 'FAQ_M2_PATH', 'FAQ_DEVICE', 'PYTHONPATH']:
        env.pop(key, None)
    with tempfile.TemporaryDirectory(prefix='rebuttal notebook test ') as tmp:
        temp = Path(tmp)
        source = temp / 'source'
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert not any('/artifacts/' in n or '__pycache__' in n for n in z.namelist())
            z.extractall(source)
        root = source / 'neurips_rebuttal_clean'
        for notebook in root.rglob('*.ipynb'):
            n = json.loads(notebook.read_text())
            for cell in n['cells']:
                if cell['cell_type'] == 'code':
                    assert cell['outputs'] == [] and cell['execution_count'] is None
                    ast.parse(''.join(cell['source']))
        backup, work = temp / 'drive outputs', temp / 'local work'
        notebooks = sorted((root / 'notebooks').glob('*.ipynb'))
        assert [p.name for p in notebooks] == [f'NeurIPS_Rebuttal_Runner_{i:02d}.ipynb' for i in range(7)]
        for notebook in notebooks:
            log_path = temp / (notebook.stem + '.log')
            with log_path.open('w') as log:
                result = subprocess.run([sys.executable, str(script), str(archive), '--one', str(notebook),
                                         '--work', str(work), '--backup', str(backup)],
                                        env=env, stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError(log_path.read_text())
            print(f'[ok] executed {notebook.name}', flush=True)

        # A fresh VM restores completed stages from the local Drive substitute.
        notebook = root / 'notebooks/NeurIPS_Rebuttal_Runner_00.ipynb'
        resumed = temp / 'fresh VM'
        result = subprocess.run([sys.executable, str(script), str(archive), '--one', str(notebook),
                                 '--work', str(resumed), '--backup', str(backup)],
                                env=env, capture_output=True, text=True)
        assert result.returncode == 0, result.stdout + result.stderr
        assert result.stdout.count('[skip]') == 10, result.stdout
        print('[ok] fresh-VM restore skips all ten completed computation stages', flush=True)

        # Remove one member of each multi-file stage; resume must repair them.
        run_root = resumed / 'neurips_rebuttal_clean'
        art = run_root / 'rebuttal_experiments/00_clean_control/artifacts/smoke'
        removed = ['factors/validation/V.pt', 'factors/final/metadata.json',
                   'logs/faq_final_model_level.csv', 'results/main_rebuttal_table.csv',
                   'results/factor_prediction_accuracy_quartiles.csv',
                   'results/selected_factor_setting.csv']
        for name in removed:
            (art / name).unlink()
        result = subprocess.run([sys.executable, str(run_root / 'run_experiment.py'),
                                 '--experiment', '00', '--smoke', '--device', 'cpu'],
                                cwd=temp, env=env, capture_output=True, text=True)
        assert result.returncode == 0, result.stdout + result.stderr
        for name in removed:
            assert (art / name).is_file(), name
        # Every regenerated CSV agrees exactly with its original completed value.
        for path in art.rglob('*.csv'):
            original = backup / '00_clean_control/artifacts/smoke' / path.relative_to(art)
            assert path.read_bytes() == original.read_bytes(), str(path)
        print('[ok] incomplete multi-file stages repair without changing results', flush=True)

        # Experiment 06 also repairs its companion outputs on resume.
        analysis = work / 'neurips_rebuttal_clean/rebuttal_experiments/06_factor_prediction_accuracy/artifacts/smoke/results'
        target = analysis / 'factor_accuracy_7p5pct_text_table.md'
        target.unlink()
        command = [sys.executable, str(work / 'neurips_rebuttal_clean/run_experiment.py'),
                   '--experiment', '06', '--smoke', '--device', 'cpu']
        result = subprocess.run(command, env=env, capture_output=True, text=True)
        assert result.returncode == 0, result.stdout + result.stderr
        assert target.is_file()
        print('[ok] analysis-only resume repairs missing text output', flush=True)
    print('PASS: seven notebook executions, Drive restore and partial-stage recovery.')


if __name__ == '__main__':
    main()
