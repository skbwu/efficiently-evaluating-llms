#!/usr/bin/env python3
"""Audit the full bundled matrices and interventions without fitting any model."""
from pathlib import Path
import sys
import tempfile
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rebuttal_experiments._shared.constants import FAMILY_RULES, get_default_config
from rebuttal_experiments._shared.data import load_base_data
from rebuttal_experiments._shared.faq import budget_count
from rebuttal_experiments._shared.io_utils import read_json
from rebuttal_experiments._shared.perturbations import prepare_experiment_data


def main():
    base = load_base_data(ROOT, {})
    assert base.m1_values.shape == (2211, 9574)
    assert base.m2_values.shape == (2212, 9574)
    for values in (base.m1_values, base.m2_values):
        assert np.isin(values, [0, 1]).all()
    for metadata, expected in [(base.m1_meta, [131, 177, 118]), (base.m2_meta, [321, 86, 55])]:
        assert metadata['model'].str.match(r'^model_[0-9]{6}(?:__.*)?$').all()
        assert metadata['sha'].str.match(r'^revision_[0-9]{6}$').all()
        counts = [int(metadata['model'].str.contains(rule['pattern'], regex=True).sum())
                  for rule in FAMILY_RULES]
        assert counts == expected
    config = get_default_config(smoke=False)
    assert [budget_count(b, 9574) for b in config['budgets']] == [239, 718, 1196]
    for experiment in sorted((ROOT / 'rebuttal_experiments').glob('0[0-5]_*')):
        spec = read_json(experiment / 'experiment.json')
        with tempfile.TemporaryDirectory() as tmp:
            result = prepare_experiment_data(base, spec, config, Path(tmp))
            assert np.array_equal(result.test_values, base.m2_values)
            assert result.manifest['selected_family_full_history_count'] == 131
            assert result.manifest['selected_family_full_test_count'] == 321
            changed = result.history_clean != result.history_perturbed
            kind = spec['perturbation']
            expected_rows = {'family_absent': 2080, 'recent_half_absent': 1105}.get(kind, 2211)
            assert len(result.history_meta) == expected_rows
            if kind.endswith('flip_5pct'):
                assert changed.sum() == 1058406
                assert np.array_equal(result.history_perturbed[changed], 1 - result.history_clean[changed])
                if kind == 'benchmark_flip_5pct':
                    eligible = np.array([name.startswith('bbh_') for name in result.question_columns])
                    assert not changed[:, ~eligible].any()
                if kind == 'family_flip_5pct':
                    assert not changed[~result.target_family_history_mask].any()
            else:
                assert not changed.any()
            if kind == 'family_absent':
                assert not result.target_family_history_mask.any()
            print(f'[ok] {experiment.name}: full history rows={expected_rows}, flips={changed.sum()}, M2 unchanged')
    print('PASS: full input shapes, binary labels, budgets, family counts and all six interventions.')


if __name__ == '__main__':
    main()
