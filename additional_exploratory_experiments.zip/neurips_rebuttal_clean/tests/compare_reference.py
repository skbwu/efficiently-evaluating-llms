#!/usr/bin/env python3
"""Compare all smoke output data to an independent original-code smoke run.

Usage: python tests/compare_reference.py /path/to/reference/package/root
Both roots must already contain fresh artifacts/smoke from the same environment.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import torch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    count = 0
    for experiment in sorted((root / 'rebuttal_experiments').glob('[0-9][0-9]_*')):
        current = experiment / 'artifacts/smoke'
        reference = args.reference / 'rebuttal_experiments' / experiment.name / 'artifacts/smoke'
        paths = sorted(p.relative_to(reference) for p in reference.rglob('*') if p.is_file())
        actual_paths = sorted(p.relative_to(current) for p in current.rglob('*') if p.is_file())
        assert paths == actual_paths, f'{experiment.name}: different artifact file sets'
        for relative in paths:
            a, b = reference / relative, current / relative
            if a.suffix == '.csv':
                left, right = pd.read_csv(a), pd.read_csv(b)
                # Identity metadata is intentionally anonymized in the distribution.
                # Keep model_index, dates, row order and every scientific value.
                for column in ('model', 'sha'):
                    if column in left.columns:
                        assert column in right.columns
                        left = left.drop(columns=column)
                        right = right.drop(columns=column)
                pd.testing.assert_frame_equal(left, right, check_exact=True)
            elif a.suffix == '.pt':
                assert torch.equal(torch.load(a, weights_only=True, map_location='cpu'),
                                   torch.load(b, weights_only=True, map_location='cpu')), str(b)
            elif a.suffix == '.npz':
                with np.load(a) as left, np.load(b) as right:
                    assert set(left.files) == set(right.files)
                    for key in left.files:
                        assert np.array_equal(left[key], right[key]), str(b)
            elif a.suffix == '.json':
                left, right = json.loads(a.read_text()), json.loads(b.read_text())
                # Paths depend on where each independent copy was extracted.
                for payload in (left, right):
                    for key in ['m1_path', 'm2_path', 'resolved_m1_path', 'resolved_m2_path']:
                        payload.pop(key, None)
                assert left == right, str(b)
            else:
                assert a.read_bytes() == b.read_bytes(), str(b)
            count += 1
        print(f'[exact match] {experiment.name}: {len(paths)} artifact files')
    print(f'PASS: {count} artifact files; exact scientific tabular values, tensors, arrays and settings; anonymized identity columns excluded.')


if __name__ == '__main__':
    main()
