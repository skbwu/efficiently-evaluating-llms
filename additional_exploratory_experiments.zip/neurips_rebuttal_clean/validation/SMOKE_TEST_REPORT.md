# Cleanup validation — 2026-10-28

## Results

All six fitted conditions completed fresh CPU smoke runs, followed by the
experiment 06 aggregation. No pre-existing artifacts were reused.

| Check | Result |
|---|---|
| Original-code reference: six pipelines + aggregation | PASS |
| Cleaned package: six pipelines + aggregation + scientific verifier | PASS |
| Comparison of 179 original/cleaned artifact files | Exact numerical agreement |
| Seven notebook workflows executed from a freshly extracted ZIP | PASS |
| Fresh working-directory restore from completed stage backups | PASS |
| Missing tensors, metadata, companion tables and model-level logs repaired | PASS |
| Analysis-only resume repairs a missing Markdown result | PASS |
| Full-size inputs and all six full-size interventions (without fitting) | PASS |
| Python syntax, shell syntax, and 13 notebook schemas | PASS |
| Inputs versus supplied originals | Only model/revision identifiers changed |

The reference comparison checks all scientific CSV values exactly, exact
equality of saved factor tensors and corruption-index arrays, and equality of settings/manifests
apart from machine-dependent input paths. Anonymized `model` and `sha`
identity columns are excluded; model indices, dates and row order are compared.
No numerical tolerance was used for this comparison. The input outcome matrices, estimator/sampling equations, default
settings, seeds and perturbation implementation were preserved.

The scientific verifier checks clean M2 against the original data subset,
clean historical labels, exact corruption counts and eligible blocks, retained
family/temporal rows, saved corruption indices, baseline historical means,
factor shapes and finite values, budgets, seeds, coverage bounds, uniform ESS,
model-level log completeness, and final aggregation completeness.

Full-size data checks confirm M1 = 2,211 × 9,574, M2 = 2,212 × 9,574,
binary labels, budgets 239/718/1,196, and family counts 131/321. Full-size
family missingness retains 2,080 rows; temporal missingness retains 1,105 rows.
Each corruption condition flips exactly 1,058,406 eligible cells. M2 remains
unchanged in all conditions.

## Test environment and scope

Python 3.12.12, macOS arm64, CPU. Package versions are recorded in
`../requirements-tested.txt`. The original smoke suite took approximately
43 seconds; the anonymized cleaned suite with its additional verifier took
approximately 47 seconds in this environment.

Smoke runs use 96 historical rows, 48 test rows, 120 questions, 15 factor
epochs, reduced tuning grids, one validation seed and three final seeds.
They test integration and numerical preservation, not scientific performance.
Full fitting runs and GPU equivalence were not rerun.

Notebook code cells were executed in order with only Google Drive mounting
substituted by a local directory and configuration changed to local CPU smoke
paths. The exact extraction, dependency detection, launcher, backup, restore,
aggregation and display cells executed. This does not test Google's hosted
Colab runtime, authentication, remote Drive service or CUDA.

## Distribution privacy review

Notebook outputs and original session metadata were discarded. Validation
logs use a generic package-root placeholder in place of personal filesystem
paths. Old run artifacts, archives, downloaded copies, editor histories,
caches and environment files are excluded.

The included source, documentation, notebook JSON, logs, filenames and input
metadata were scanned for email addresses, private local paths, the requested
personal-name patterns, common API-token and private-key formats, credential
assignments and profanity. No matches remained in the distribution.
Model/revision identifiers are consistently anonymized; family tags preserve every original membership
of the three registered family rules. Release dates, row order, duplicate
identity relationships, question headers and all outcome values are unchanged.
No identity mapping is distributed.
Outdated setup text and speculative result prose were removed.

## Reproduce

From the extracted package root:

```bash
bash rebuttal_experiments/run_all_smoke_tests.sh --force
python tests/check_full_inputs.py
python tests/check_notebooks.py /path/to/neurips_rebuttal_clean.zip
```

The notebook-cell test also needs IPython (`requirements-notebooks.txt`). To
compare against an independently run original source copy in the same Python
and hardware environment:

```bash
python tests/compare_reference.py /path/to/original-reference-root
```

The original source copy is intentionally not duplicated in this distribution.
Compact logs for these checks accompany this report.
