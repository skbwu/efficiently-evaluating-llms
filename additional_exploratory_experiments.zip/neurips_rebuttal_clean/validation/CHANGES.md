# Cleanup changes

- Bundled the full M1/M2 outcomes with anonymized model/revision identifiers; default paths now work after extraction.
- Replaced six large saved notebook sessions with small output-free launchers.
- Added a separate CPU launcher for experiment 06 and a shared Python entry point.
- Removed the old ZIP checksum requirement, external data-copy setup, background
  rsync loop, and dependency on an external repository checkout.
- Save completed stages to the chosen backup directory and restore them on resume.
  Resume checks require all files produced by a stage, including both factor tensors.
- Retained all original scientific equations, settings, seeds, row selections,
  corruption rules, and baseline selection. The numeric smoke artifacts match the
  original-code reference exactly in the recorded environment.
- Kept the original stage wrappers and shell commands; shortened repeated comments
  and updated documentation and result-notebook path handling.
- Replaced a self-comparison in the old M2 verifier with comparison against the
  original input subset. Added intervention, fairness, completeness and output checks.
- Excluded historical artifacts, duplicate downloads, old archives, notebook
  outputs, caches and local editor histories. Sanitized packaged validation logs.
- Anonymized model/revision identifiers consistently, preserving all registered
  family memberships, release dates, row order and outcome values. Reviewed
  package text and input metadata for personal identifiers, credentials,
  the requested personal-name patterns, and profanity; see SMOKE_TEST_REPORT.md.

The original workspace files are outside this distribution and were not modified.
