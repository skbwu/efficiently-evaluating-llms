#!/usr/bin/env python3
"""Run one condition locally or in Colab, optionally saving completed stages to Drive."""
from __future__ import annotations

import argparse
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXPERIMENTS = (
    "00_clean_control",
    "01_family_missingness",
    "02_temporal_missingness",
    "03_random_label_corruption",
    "04_benchmark_label_corruption",
    "05_family_label_corruption",
    "06_factor_prediction_accuracy",
)


class Tee:
    def __init__(self, console, log):
        self.console, self.log = console, log

    def write(self, text):
        self.console.write(text)
        self.log.write(text)
        self.flush()
        return len(text)

    def flush(self):
        self.console.flush()
        self.log.flush()


def run_experiment(experiment, *, smoke=False, device=None, backup_root=None, force=False):
    if smoke:
        for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
            os.environ.setdefault(name, "1")
    from rebuttal_experiments._shared.cli import run
    from rebuttal_experiments._shared.pipeline import PIPELINE_ORDER

    experiment_dir = ROOT / "rebuttal_experiments" / experiment
    mode = "smoke" if smoke else "full"
    local_art = experiment_dir / "artifacts" / mode
    backup = Path(backup_root).expanduser() / experiment if backup_root else None
    log_dir = ROOT / "run_logs"
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / f"{experiment}_{mode}.log"

    if backup:
        backup.mkdir(parents=True, exist_ok=True)
        saved = backup / "artifacts" / mode
        if saved.is_dir() and not force:
            shutil.copytree(saved, local_art, dirs_exist_ok=True)

    # Experiment 06 reads only these completed result tables; no GPU or refit.
    if experiment == EXPERIMENTS[6] and backup_root:
        for source in EXPERIMENTS[:2]:
            relative = Path(source) / "artifacts" / mode / "results"
            saved = Path(backup_root).expanduser() / relative
            target = ROOT / "rebuttal_experiments" / relative
            target.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved / "factor_accuracy_stratified_metrics.csv", target)

    def sync_completed_stage(stage):
        if backup:
            shutil.copytree(local_art, backup / "artifacts" / mode, dirs_exist_ok=True)
            shutil.copy2(log_path, backup / log_path.name)
            (backup / f"last_completed_stage_{mode}.txt").write_text(stage + "\n")
            print(f"[saved to Drive] {stage}", flush=True)

    status = 1
    with log_path.open("a", encoding="utf-8") as log:
        try:
            with redirect_stdout(Tee(sys.stdout, log)), redirect_stderr(Tee(sys.stderr, log)):
                print(f"\n{datetime.now(timezone.utc).isoformat()} {experiment} {mode}")
                if experiment == EXPERIMENTS[6]:
                    command = [sys.executable, str(experiment_dir / "factor_prediction_accuracy.py"),
                               "--mode", mode]
                    if force:
                        command.append("--force")
                    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
                    print(result.stdout, end="")
                    print(result.stderr, end="", file=sys.stderr)
                    result.check_returncode()
                    sync_completed_stage("factor_accuracy_aggregation")
                else:
                    run(experiment_dir=experiment_dir, stages=PIPELINE_ORDER,
                        smoke=smoke, device=device, task_id=0, num_tasks=1,
                        force=force, endpoint_mode=None, after_stage=sync_completed_stage)
                status = 0
        finally:
            log.flush()
            if backup:
                shutil.copy2(log_path, backup / log_path.name)
                (backup / f"exit_status_{mode}.txt").write_text(str(status) + "\n")
    print(f"Results: {local_art / 'results'}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--experiment", required=True,
                        choices=list(EXPERIMENTS) + [f"{i:02d}" for i in range(7)])
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--device", default=None, help="cpu or cuda; defaults to CUDA when available")
    parser.add_argument("--backup-root", type=Path, help="Optional Drive/output folder")
    parser.add_argument("--force", action="store_true", help="Recompute every stage")
    args = parser.parse_args()
    experiment = EXPERIMENTS[int(args.experiment)] if len(args.experiment) == 2 else args.experiment
    run_experiment(experiment, smoke=args.smoke, device=args.device,
                   backup_root=args.backup_root, force=args.force)


if __name__ == "__main__":
    main()
