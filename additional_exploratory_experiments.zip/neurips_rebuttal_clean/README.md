# NeurIPS 2026 rebuttal experiments

Self-contained code and full stitched-suite inputs for experiments 00–06.
No original repository checkout or separate data download is required.

## Run in Google Colab

1. Extract this ZIP on your computer to access `notebooks/`.
2. Upload **the same `neurips_rebuttal_clean.zip`** to Google Drive at
   `MyDrive/neurips_rebuttal_inputs/`. Leave the ZIP intact on Drive.
3. Open `notebooks/NeurIPS_Rebuttal_Runner_00.ipynb` in Colab using
   **File → Upload notebook**. Choose a GPU runtime for a full run.
4. Run the cells in order. The setup mounts Drive, extracts the code and both
   inputs to the local VM, and installs only missing Python packages.
5. Use runners 01–05 for the corresponding conditions. After 00 and 01 finish,
   run notebook 06 on CPU to generate the factor-accuracy comparison.

For a smoke run, change `MODE = "smoke"` and `DEVICE = "cpu"` in the notebook.
Set `FORCE = True` to recompute every stage. Each notebook selects its experiment
already; the six fitting notebooks may run in separate Colab sessions.

Outputs are saved under
`MyDrive/neurips_rebuttal_runs_clean/<experiment>/artifacts/<mode>/`.
Completed stages are copied to Drive before the next stage starts. If Colab
stops mid-stage, rerunning resumes completed stages and recomputes that stage.
Console logs are saved at stage boundaries and normal/error exit; a hard VM
termination can lose the current stage's unsaved log tail. There is no periodic
background synchronization or ZIP checksum gate.

Keep the same code, inputs, device and settings when resuming. Use a different
`DRIVE_RUN_ROOT` for a different configuration or an audit run. The default
output folder is separate from the historical runs supplied with this project.

## Run locally

Python 3.10 or later:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
bash rebuttal_experiments/run_all_smoke_tests.sh --force
```

The smoke script runs all six fitted conditions, experiment 06, and the
scientific artifact checks. It uses the bundled full inputs to select the
original deterministic smoke subset: 96 historical rows, 48 test rows,
120 questions, 15 factor epochs, reduced tuning grids and three final seeds.
It does not reproduce full-run scientific results.

Run an individual condition through the same entry point used by the notebooks:

```bash
python run_experiment.py --experiment 00 --smoke --device cpu
python run_experiment.py --experiment 00 --device cuda
python run_experiment.py --experiment 06
```

`--backup-root /path/to/output` enables stage-level backups locally as well.
The original per-experiment shell entry points and source-named stage wrappers
remain available. Run a stage wrapper as a module from the package root, e.g.
`python -m rebuttal_experiments.00_clean_control.prepare_data --smoke`.
The shell scripts use `python3`, or the interpreter set in `PYTHON`.
`FAQ_M1_PATH` and `FAQ_M2_PATH` optionally override the bundled inputs.
For local notebook use, install `requirements-notebooks.txt`.

## Contents

| Path | Purpose |
|---|---|
| `notebooks/NeurIPS_Rebuttal_Runner_00.ipynb` … `06.ipynb` | Colab launchers; saved outputs cleared |
| `run_experiment.py` | Shared launcher, resume and completed-stage backups |
| `rebuttal_experiments/_shared/` | Shared numerical implementation |
| `rebuttal_experiments/00_*` … `05_*` | Condition specifications, wrappers and result viewers |
| `rebuttal_experiments/06_factor_prediction_accuracy/` | Analysis of the completed 00/01 results |
| `data/M1.csv`, `data/M2.csv` | Full inputs with anonymized model/revision identifiers |
| `validation/` | Cleanup smoke-test report and compact logs |
| `tests/` | Launcher/notebook/resume regression checks |

Model and revision identifiers are anonymized. Family tags preserve the exact
original memberships of all three registered family rules; question outcomes,
release dates and row order are unchanged. No identity mapping is included.

M1 contains 2,211 models; M2 contains 2,212 models. Each has three metadata
columns and 9,574 question columns. Full-run budgets remain 239, 718 and
1,196 queries (2.5%, 7.5%, 12.5%). See each experiment's README for the
intervention and `rebuttal_experiments/SOURCE_MAPPING.md` for numerical details.

The original estimator equations, tuning grids, seeds, perturbations, baseline
selection, and `source_exact` interval endpoint behavior are preserved.
`corrected_clip` remains a separate audit option in the original stage CLI.
Run the full clean control before interpreting full stress-test results.

Old run outputs, duplicate Drive downloads, old ZIPs, notebook outputs, editor
metadata and caches are excluded. The original workspace files were retained.
Fresh runtime artifacts are generated only when you run the package.
